<?php
// check if value was posted
if($_POST){
 
    // include database and object file
    include_once '../config/database.php';
    include_once '../objects/teks_berjalan.php';
 
    // get database connection
    $database = new Database();
    $db = $database->getConnection();
 
    // prepare product object
    $teks = new Teks($db);
     
    // set product id to be deleted
    $teks->id = $_POST['object_id'];
     
    // delete the product
    if($teks->delete()){
        echo "Event Dihapus.";
    }
     
    // if unable to delete the product
    else{
        echo "Gagal Menghapus.";
    }
}
?>