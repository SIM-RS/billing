<?php
include_once '../config/database.php';
include_once '../objects/teks_berjalan.php';
 
$database = new Database();
$db = $database->getConnection();
 
$teks = new Teks($db);
$page_title = "Buat Running Teks";
include_once "header.php";
 
echo "<div class='right-button-margin'>";
    echo "<a href='index.php' class='btn btn-default pull-right'>Home</a>";
echo "</div>";
 
?>

<?php 
if($_POST){
 
    $teks->teks = $_POST['teks'];
    $teks->tanggal = $_POST['tanggal'];
    $teks->status = $_POST['status'];

    if($teks->create()){
        echo "<div class='alert alert-success'>Running Teks Telah disimpan</div>";
    }
 
    else{
        echo "<div class='alert alert-danger'>Gagal Menyimpan running teks</div>";
    }
}
?>
<!-- html -->
<form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>" method="post" enctype="multipart/form-data">

 
    <table class='table table-hover table-responsive table-bordered'>
 

        <tr>
            <td>Teks</td>
            <td colspan ='2'><textarea name='teks' class='form-control'></textarea></td>
        </tr>
    
        <tr>
        <td>Tanggal Berakhir</td>
        <td colspan = '2'>
        <div class="form-group">  
                       
                <div class="input-group date form_date col-md-5" data-date="" data-date-format="yyyy-mm-dd" data-link-field="dtp_input1" data-link-format="yyyy-mm-dd">
                    <input class="form-control" size="10" type="text" name="tanggal">
                        <span class="input-group-addon"><span class="glyphicon glyphicon-calendar">V</span></span>
                </div>
                <input type="hidden" id="dtp_input1" value=""/> 
              
            </div></td>
        </tr>
        
        <tr>
    
        <tr>
        <td>Status</td>
        <td colspan='2'>
        <select class='form-control' name='status'>
                <option value='1'>Aktif</option>
                <option value='0'>Tidak Aktif</option>
            
            </select>
            </td>
            </tr>
            <tr>
            <td></td>
            <td colspan ='2'>
                <button type="submit" class="btn btn-primary">Create</button>
            </td>
        </tr>
 
    </table>
</form>
<?php
 
// footer
include_once "footer.php";
?>