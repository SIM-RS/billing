<?php
// set page headers
// get ID of the product to be read
$id = isset($_GET['id']) ? $_GET['id'] : die('ERROR: missing ID.');
 
// include database and object files
include_once '../config/database.php';
include_once '../objects/teks_berjalan.php';
 
// get database connection
$database = new Database();
$db = $database->getConnection();
 
// prepare objects
$teks = new Teks($db);
 
// set ID property of product to be read
$teks->id = $id;
 
// read the details of product to be read
$teks->readOne();
$page_title = "Detail Teks";
include_once "header.php";
 
// read products button
echo "<div class='right-button-margin'>";
    echo "<a href='index.php' class='btn btn-primary pull-right'>";
        echo "Home";
    echo "</a>";
echo "</div>";
 // HTML table for displaying a product details
echo "<table class='table table-hover table-responsive table-bordered'>";
 
echo "<tr>";
    echo "<td>Teks</td>";
    echo "<td>{$teks->teks}</td>";
echo "</tr>";


echo "<tr>";
    echo "<td>Tanggal Berakhir</td>";
    echo "<td>{$teks->tanggal}</td>";
echo "</tr>";


echo "</table>";
// set footer
include_once "footer.php";
?>