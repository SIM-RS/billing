<marquee scrollamount="2">marquee scrollamount="2"</marquee>
<marquee scrollamount="5">marquee scrollamount="5"</marquee>
<marquee scrollamount="8">marquee scrollamount="8"</marquee>
<marquee scrollamount="10">marquee scrollamount="10"</marquee>
<marquee scrollamount="15">marquee scrollamount="15"</marquee>
<marquee>Rumah Sakit Prima Husada Cipta Medan Tanggal 2018-09-15</marquee>
<marquee scrolldelay="100">marquee scrolldelay="100"</marquee>
<marquee scrolldelay="200">marquee scrolldelay="200"</marquee>
<marquee scrolldelay="300">marquee scrolldelay="300"</marquee>
<?php
include_once '../config/database.php';
include_once '../objects/event.php';
include_once '../objects/teks_berjalan.php';

$database = new Database();
$db = $database->getConnection();

$event = new Event($db);
$teks = new Teks($db);

?>
<?php 
$stmt = $teks->tampilkanTeks(); 
if($stmt == FALSE){
    die(mysql_error());
}
	 while ($row = $stmt->fetch(PDO::FETCH_ASSOC)){
                    extract($row);
					?>
    <marquee scrollamount="<?= $kecepatan; ?>"> <h1><?= $teks; ?><h1></marquee>
	<?php } ?>
