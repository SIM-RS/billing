        <?php
            if($teks->warna_bg == 'Black'){
                ?>
        <tr>
            <td>Warna Background</td>
            <td colspan ='2'>
            <select class='form-control' name='warna_bg'>
                <option value='Black' selected >Hitam</option>
                 <option value='White'>Putih</option> 
                  <option value='blue'>Biru</option> 
                <option value='skyblue'>Biru Muda</option>
                <option value='Red'>Merah</option>
                 <option value='yellow'>Kuning</option>
                 <option value='gray'>Abu-Abu</option>
                 <option value='Maroon'>Maroon</option>
                 <option value='green'>Hijau</option>
                 <option value='lime'>Hijau Muda</option>
                 <option value='navy'>Navy</option>
                 <option value='purple'>Ungu</option>
                 <option value='teal'>Teal</option> 
            </select></td>
        </tr>
        <?php
        }elseif($teks->warna_bg == 'White'){
            ?>
        <tr>
            <td>Warna Background</td>
            <td colspan ='2'>
            <select class='form-control' name='warna_bg'>
                <option value='Black' >Hitam</option>
                 <option value='White' selected>Putih</option> 
                  <option value='blue'>Biru</option> 
                <option value='skyblue'>Biru Muda</option>
                <option value='Red'>Merah</option>
                 <option value='yellow'>Kuning</option>
                 <option value='gray'>Abu-Abu</option>
                 <option value='Maroon'>Maroon</option>
                 <option value='green'>Hijau</option>
                 <option value='lime'>Hijau Muda</option>
                 <option value='navy'>Navy</option>
                 <option value='purple'>Ungu</option>
                 <option value='teal'>Teal</option> 
            </select></td>
        </tr>
        <?php
        }elseif($teks->warna_bg == 'blue'){
            ?>
        <tr>
            <td>Warna Background</td>
            <td colspan ='2'>
            <select class='form-control' name='warna_bg'>
                <option value='Black'  >Hitam</option>
                 <option value='White'>Putih</option> 
                  <option value='blue' selected>Biru</option> 
                <option value='skyblue'>Biru Muda</option>
                <option value='Red'>Merah</option>
                 <option value='yellow'>Kuning</option>
                 <option value='gray'>Abu-Abu</option>
                 <option value='Maroon'>Maroon</option>
                 <option value='green'>Hijau</option>
                 <option value='lime'>Hijau Muda</option>
                 <option value='navy'>Navy</option>
                 <option value='purple'>Ungu</option>
                 <option value='teal'>Teal</option> 
            </select></td>
        </tr>
        <?php
        }elseif($teks->warna_bg == 'skyblue'){
            ?>
        <tr>
            <td>Warna Background</td>
            <td colspan ='2'>
            <select class='form-control' name='warna_bg'>
                <option value='Black' >Hitam</option>
                 <option value='White'>Putih</option> 
                  <option value='blue'>Biru</option> 
                <option value='skyblue' selected>Biru Muda</option>
                <option value='Red'>Merah</option>
                 <option value='yellow'>Kuning</option>
                 <option value='gray'>Abu-Abu</option>
                 <option value='Maroon'>Maroon</option>
                 <option value='green'>Hijau</option>
                 <option value='lime'>Hijau Muda</option>
                 <option value='navy'>Navy</option>
                 <option value='purple'>Ungu</option>
                 <option value='teal'>Teal</option> 
            </select></td>
        </tr>  <?php
        }elseif($teks->warna_bg == 'Red'){
            ?>
        <tr>
            <td>Warna Background</td>
            <td colspan ='2'>
            <select class='form-control' name='warna_bg'>
                <option value='Black' >Hitam</option>
                 <option value='White'>Putih</option> 
                  <option value='blue'>Biru</option> 
                <option value='skyblue'>Biru Muda</option>
                <option value='Red' selected>Merah</option>
                 <option value='yellow'>Kuning</option>
                 <option value='gray'>Abu-Abu</option>
                 <option value='Maroon'>Maroon</option>
                 <option value='green'>Hijau</option>
                 <option value='lime'>Hijau Muda</option>
                 <option value='navy'>Navy</option>
                 <option value='purple'>Ungu</option>
                 <option value='teal'>Teal</option> 
            </select></td>
        </tr>  <?php
        }elseif($teks->warna_bg == 'yellow'){
            ?>
        <tr>
            <td>Warna Background</td>
            <td colspan ='2'>
            <select class='form-control' name='warna_bg'>
                <option value='Black' >Hitam</option>
                 <option value='White'>Putih</option> 
                  <option value='blue'>Biru</option> 
                <option value='skyblue'>Biru Muda</option>
                <option value='Red'>Merah</option>
                 <option value='yellow' selected>Kuning</option>
                 <option value='gray'>Abu-Abu</option>
                 <option value='Maroon'>Maroon</option>
                 <option value='green'>Hijau</option>
                 <option value='lime'>Hijau Muda</option>
                 <option value='navy'>Navy</option>
                 <option value='purple'>Ungu</option>
                 <option value='teal'>Teal</option> 
            </select></td>
        </tr>  <?php
        }elseif($teks->warna_bg == 'gray'){
            ?>
        <tr>
            <td>Warna Background</td>
            <td colspan ='2'>
            <select class='form-control' name='warna_bg'>
                <option value='Black' >Hitam</option>
                 <option value='White'>Putih</option> 
                  <option value='blue'>Biru</option> 
                <option value='skyblue'>Biru Muda</option>
                <option value='Red'>Merah</option>
                 <option value='yellow'>Kuning</option>
                 <option value='gray' selected>Abu-Abu</option>
                 <option value='Maroon'>Maroon</option>
                 <option value='green'>Hijau</option>
                 <option value='lime'>Hijau Muda</option>
                 <option value='navy'>Navy</option>
                 <option value='purple'>Ungu</option>
                 <option value='teal'>Teal</option> 
            </select></td>
        </tr>  <?php
        }elseif($teks->warna_bg == 'Maroon'){
            ?>
        <tr>
            <td>Warna Background</td>
            <td colspan ='2'>
            <select class='form-control' name='warna_bg'>
                <option value='Black' >Hitam</option>
                 <option value='White'>Putih</option> 
                  <option value='blue'>Biru</option> 
                <option value='skyblue'>Biru Muda</option>
                <option value='Red'>Merah</option>
                 <option value='yellow'>Kuning</option>
                 <option value='gray'>Abu-Abu</option>
                 <option value='Maroon' selected>Maroon</option>
                 <option value='green'>Hijau</option>
                 <option value='lime'>Hijau Muda</option>
                 <option value='navy'>Navy</option>
                 <option value='purple'>Ungu</option>
                 <option value='teal'>Teal</option> 
            </select></td>
        </tr>  <?php
        }elseif($teks->warna_bg == 'green'){
            ?>
        <tr>
            <td>Warna Background</td>
            <td colspan ='2'>
            <select class='form-control' name='warna_bg'>
                <option value='Black'  >Hitam</option>
                 <option value='White'>Putih</option> 
                  <option value='blue'>Biru</option> 
                <option value='skyblue'>Biru Muda</option>
                <option value='Red'>Merah</option>
                 <option value='yellow'>Kuning</option>
                 <option value='gray'>Abu-Abu</option>
                 <option value='Maroon'>Maroon</option>
                 <option value='green' selected>Hijau</option>
                 <option value='lime'>Hijau Muda</option>
                 <option value='navy'>Navy</option>
                 <option value='purple'>Ungu</option>
                 <option value='teal'>Teal</option> 
            </select></td>
        </tr>  <?php
        }elseif($teks->warna_bg == 'lime'){
            ?>
        <tr>
            <td>Warna Background</td>
            <td colspan ='2'>
            <select class='form-control' name='warna_bg'>
                <option value='Black'  >Hitam</option>
                 <option value='White'>Putih</option> 
                  <option value='blue'>Biru</option> 
                <option value='skyblue'>Biru Muda</option>
                <option value='Red'>Merah</option>
                 <option value='yellow'>Kuning</option>
                 <option value='gray'>Abu-Abu</option>
                 <option value='Maroon'>Maroon</option>
                 <option value='green'>Hijau</option>
                 <option value='lime' selected>Hijau Muda</option>
                 <option value='navy'>Navy</option>
                 <option value='purple'>Ungu</option>
                 <option value='teal'>Teal</option> 
            </select></td>
        </tr>  <?php
        }elseif($teks->warna_bg == 'navy'){
            ?>
        <tr>
            <td>Warna Background</td>
            <td colspan ='2'>
            <select class='form-control' name='warna_bg'>
                <option value='Black'  >Hitam</option>
                 <option value='White'>Putih</option> 
                  <option value='blue'>Biru</option> 
                <option value='skyblue'>Biru Muda</option>
                <option value='Red'>Merah</option>
                 <option value='yellow'>Kuning</option>
                 <option value='gray'>Abu-Abu</option>
                 <option value='Maroon'>Maroon</option>
                 <option value='green'>Hijau</option>
                 <option value='lime'>Hijau Muda</option>
                 <option value='navy' selected>Navy</option>
                 <option value='purple'>Ungu</option>
                 <option value='teal'>Teal</option> 
            </select></td>
        </tr>  <?php
        }elseif($teks->warna_bg == 'purple'){
            ?>
        <tr>
            <td>Warna Background</td>
            <td colspan ='2'>
            <select class='form-control' name='warna_bg'>
                <option value='Black'  >Hitam</option>
                 <option value='White'>Putih</option> 
                  <option value='blue'>Biru</option> 
                <option value='skyblue'>Biru Muda</option>
                <option value='Red'>Merah</option>
                 <option value='yellow'>Kuning</option>
                 <option value='gray'>Abu-Abu</option>
                 <option value='Maroon'>Maroon</option>
                 <option value='green'>Hijau</option>
                 <option value='lime'>Hijau Muda</option>
                 <option value='navy'>Navy</option>
                 <option value='purple' selected>Ungu</option>
                 <option value='teal'>Teal</option> 
            </select></td>
        </tr>  <?php
        }elseif($teks->warna_bg == 'teal'){
            ?>
        <tr>
            <td>Warna Background</td>
            <td colspan ='2'>
            <select class='form-control' name='warna_bg'>
                <option value='Black'  >Hitam</option>
                 <option value='White'>Putih</option> 
                  <option value='blue'>Biru</option> 
                <option value='skyblue'>Biru Muda</option>
                <option value='Red'>Merah</option>
                 <option value='yellow'>Kuning</option>
                 <option value='gray'>Abu-Abu</option>
                 <option value='Maroon'>Maroon</option>
                 <option value='green'>Hijau</option>
                 <option value='lime'>Hijau Muda</option>
                 <option value='navy'>Navy</option>
                 <option value='purple'>Ungu</option>
                 <option value='teal' selected>Teal</option> 
            </select></td>
        </tr>
        <?php } ?>







        <?php
            if($teks->warna_teks == 'Black'){
                ?>
        <tr>
            <td>Warna Tulisan</td>
            <td colspan ='2'>
            <select class='form-control' name='warna_teks'>
                <option value='Black' selected >Hitam</option>
                 <option value='White'>Putih</option> 
                  <option value='blue'>Biru</option> 
                <option value='skyblue'>Biru Muda</option>
                <option value='Red'>Merah</option>
                 <option value='yellow'>Kuning</option>
                 <option value='gray'>Abu-Abu</option>
                 <option value='Maroon'>Maroon</option>
                 <option value='green'>Hijau</option>
                 <option value='lime'>Hijau Muda</option>
                 <option value='navy'>Navy</option>
                 <option value='purple'>Ungu</option>
                 <option value='teal'>Teal</option> 
            </select></td>
        </tr>
        <?php
        }elseif($teks->warna_teks == 'White'){
            ?>
        <tr>
            <td>Warna Tulisan</td>
            <td colspan ='2'>
            <select class='form-control' name='warna_teks'>
                <option value='Black' >Hitam</option>
                 <option value='White' selected>Putih</option> 
                  <option value='blue'>Biru</option> 
                <option value='skyblue'>Biru Muda</option>
                <option value='Red'>Merah</option>
                 <option value='yellow'>Kuning</option>
                 <option value='gray'>Abu-Abu</option>
                 <option value='Maroon'>Maroon</option>
                 <option value='green'>Hijau</option>
                 <option value='lime'>Hijau Muda</option>
                 <option value='navy'>Navy</option>
                 <option value='purple'>Ungu</option>
                 <option value='teal'>Teal</option> 
            </select></td>
        </tr>
        <?php
        }elseif($teks->warna_teks == 'blue'){
            ?>
        <tr>
            <td>Warna Tulisan</td>
            <td colspan ='2'>
            <select class='form-control' name='warna_teks'>
                <option value='Black'  >Hitam</option>
                 <option value='White'>Putih</option> 
                  <option value='blue' selected>Biru</option> 
                <option value='skyblue'>Biru Muda</option>
                <option value='Red'>Merah</option>
                 <option value='yellow'>Kuning</option>
                 <option value='gray'>Abu-Abu</option>
                 <option value='Maroon'>Maroon</option>
                 <option value='green'>Hijau</option>
                 <option value='lime'>Hijau Muda</option>
                 <option value='navy'>Navy</option>
                 <option value='purple'>Ungu</option>
                 <option value='teal'>Teal</option> 
            </select></td>
        </tr>
        <?php
        }elseif($teks->warna_teks == 'skyblue'){
            ?>
        <tr>
            <td>Warna Tulisan</td>
            <td colspan ='2'>
            <select class='form-control' name='warna_teks'>
                <option value='Black' >Hitam</option>
                 <option value='White'>Putih</option> 
                  <option value='blue'>Biru</option> 
                <option value='skyblue' selected>Biru Muda</option>
                <option value='Red'>Merah</option>
                 <option value='yellow'>Kuning</option>
                 <option value='gray'>Abu-Abu</option>
                 <option value='Maroon'>Maroon</option>
                 <option value='green'>Hijau</option>
                 <option value='lime'>Hijau Muda</option>
                 <option value='navy'>Navy</option>
                 <option value='purple'>Ungu</option>
                 <option value='teal'>Teal</option> 
            </select></td>
        </tr>  <?php
        }elseif($teks->warna_teks == 'Red'){
            ?>
        <tr>
            <td>Warna Tulisan</td>
            <td colspan ='2'>
            <select class='form-control' name='warna_teks'>
                <option value='Black' >Hitam</option>
                 <option value='White'>Putih</option> 
                  <option value='blue'>Biru</option> 
                <option value='skyblue'>Biru Muda</option>
                <option value='Red' selected>Merah</option>
                 <option value='yellow'>Kuning</option>
                 <option value='gray'>Abu-Abu</option>
                 <option value='Maroon'>Maroon</option>
                 <option value='green'>Hijau</option>
                 <option value='lime'>Hijau Muda</option>
                 <option value='navy'>Navy</option>
                 <option value='purple'>Ungu</option>
                 <option value='teal'>Teal</option> 
            </select></td>
        </tr>  <?php
        }elseif($teks->warna_teks == 'yellow'){
            ?>
        <tr>
            <td>Warna Tulisan</td>
            <td colspan ='2'>
            <select class='form-control' name='warna_teks'>
                <option value='Black' >Hitam</option>
                 <option value='White'>Putih</option> 
                  <option value='blue'>Biru</option> 
                <option value='skyblue'>Biru Muda</option>
                <option value='Red'>Merah</option>
                 <option value='yellow' selected>Kuning</option>
                 <option value='gray'>Abu-Abu</option>
                 <option value='Maroon'>Maroon</option>
                 <option value='green'>Hijau</option>
                 <option value='lime'>Hijau Muda</option>
                 <option value='navy'>Navy</option>
                 <option value='purple'>Ungu</option>
                 <option value='teal'>Teal</option> 
            </select></td>
        </tr>  <?php
        }elseif($teks->warna_teks == 'gray'){
            ?>
        <tr>
            <td>Warna Tulisan</td>
            <td colspan ='2'>
            <select class='form-control' name='warna_teks'>
                <option value='Black' >Hitam</option>
                 <option value='White'>Putih</option> 
                  <option value='blue'>Biru</option> 
                <option value='skyblue'>Biru Muda</option>
                <option value='Red'>Merah</option>
                 <option value='yellow'>Kuning</option>
                 <option value='gray' selected>Abu-Abu</option>
                 <option value='Maroon'>Maroon</option>
                 <option value='green'>Hijau</option>
                 <option value='lime'>Hijau Muda</option>
                 <option value='navy'>Navy</option>
                 <option value='purple'>Ungu</option>
                 <option value='teal'>Teal</option> 
            </select></td>
        </tr>  <?php
        }elseif($teks->warna_teks == 'Maroon'){
            ?>
        <tr>
            <td>Warna Tulisan</td>
            <td colspan ='2'>
            <select class='form-control' name='warna_teks'>
                <option value='Black' >Hitam</option>
                 <option value='White'>Putih</option> 
                  <option value='blue'>Biru</option> 
                <option value='skyblue'>Biru Muda</option>
                <option value='Red'>Merah</option>
                 <option value='yellow'>Kuning</option>
                 <option value='gray'>Abu-Abu</option>
                 <option value='Maroon' selected>Maroon</option>
                 <option value='green'>Hijau</option>
                 <option value='lime'>Hijau Muda</option>
                 <option value='navy'>Navy</option>
                 <option value='purple'>Ungu</option>
                 <option value='teal'>Teal</option> 
            </select></td>
        </tr>  <?php
        }elseif($teks->warna_teks == 'green'){
            ?>
        <tr>
            <td>Warna Tulisan</td>
            <td colspan ='2'>
            <select class='form-control' name='warna_teks'>
                <option value='Black'  >Hitam</option>
                 <option value='White'>Putih</option> 
                  <option value='blue'>Biru</option> 
                <option value='skyblue'>Biru Muda</option>
                <option value='Red'>Merah</option>
                 <option value='yellow'>Kuning</option>
                 <option value='gray'>Abu-Abu</option>
                 <option value='Maroon'>Maroon</option>
                 <option value='green' selected>Hijau</option>
                 <option value='lime'>Hijau Muda</option>
                 <option value='navy'>Navy</option>
                 <option value='purple'>Ungu</option>
                 <option value='teal'>Teal</option> 
            </select></td>
        </tr>  <?php
        }elseif($teks->warna_teks == 'lime'){
            ?>
        <tr>
            <td>Warna Tulisan</td>
            <td colspan ='2'>
            <select class='form-control' name='warna_teks'>
                <option value='Black'  >Hitam</option>
                 <option value='White'>Putih</option> 
                  <option value='blue'>Biru</option> 
                <option value='skyblue'>Biru Muda</option>
                <option value='Red'>Merah</option>
                 <option value='yellow'>Kuning</option>
                 <option value='gray'>Abu-Abu</option>
                 <option value='Maroon'>Maroon</option>
                 <option value='green'>Hijau</option>
                 <option value='lime' selected>Hijau Muda</option>
                 <option value='navy'>Navy</option>
                 <option value='purple'>Ungu</option>
                 <option value='teal'>Teal</option> 
            </select></td>
        </tr>  <?php
        }elseif($teks->warna_teks == 'navy'){
            ?>
        <tr>
            <td>Warna Tulisan</td>
            <td colspan ='2'>
            <select class='form-control' name='warna_teks'>
                <option value='Black'  >Hitam</option>
                 <option value='White'>Putih</option> 
                  <option value='blue'>Biru</option> 
                <option value='skyblue'>Biru Muda</option>
                <option value='Red'>Merah</option>
                 <option value='yellow'>Kuning</option>
                 <option value='gray'>Abu-Abu</option>
                 <option value='Maroon'>Maroon</option>
                 <option value='green'>Hijau</option>
                 <option value='lime'>Hijau Muda</option>
                 <option value='navy' selected>Navy</option>
                 <option value='purple'>Ungu</option>
                 <option value='teal'>Teal</option> 
            </select></td>
        </tr>  <?php
        }elseif($teks->warna_teks == 'purple'){
            ?>
        <tr>
            <td>Warna Tulisan</td>
            <td colspan ='2'>
            <select class='form-control' name='warna_teks'>
                <option value='Black'  >Hitam</option>
                 <option value='White'>Putih</option> 
                  <option value='blue'>Biru</option> 
                <option value='skyblue'>Biru Muda</option>
                <option value='Red'>Merah</option>
                 <option value='yellow'>Kuning</option>
                 <option value='gray'>Abu-Abu</option>
                 <option value='Maroon'>Maroon</option>
                 <option value='green'>Hijau</option>
                 <option value='lime'>Hijau Muda</option>
                 <option value='navy'>Navy</option>
                 <option value='purple' selected>Ungu</option>
                 <option value='teal'>Teal</option> 
            </select></td>
        </tr>  <?php
        }elseif($teks->warna_teks == 'teal'){
            ?>
        <tr>
            <td>Warna Tulisan</td>
            <td colspan ='2'>
            <select class='form-control' name='warna_teks'>
                <option value='Black'  >Hitam</option>
                 <option value='White'>Putih</option> 
                  <option value='blue'>Biru</option> 
                <option value='skyblue'>Biru Muda</option>
                <option value='Red'>Merah</option>
                 <option value='yellow'>Kuning</option>
                 <option value='gray'>Abu-Abu</option>
                 <option value='Maroon'>Maroon</option>
                 <option value='green'>Hijau</option>
                 <option value='lime'>Hijau Muda</option>
                 <option value='navy'>Navy</option>
                 <option value='purple'>Ungu</option>
                 <option value='teal' selected>Teal</option> 
            </select></td>
        </tr>
        <?php } ?>







