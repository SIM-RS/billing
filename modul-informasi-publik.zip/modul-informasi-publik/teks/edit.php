<?php
// retrieve one product will be here
 // get ID of the product to be edited
$id = isset($_GET['id']) ? $_GET['id'] : die('ERROR: missing ID.');
 
// include database and object files
include_once '../config/database.php';
include_once '../objects/teks_berjalan.php';
 
// get database connection
$database = new Database();
$db = $database->getConnection();
 
// prepare objects
$teks = new Teks($db);
 
// set ID property of product to be edited
$teks->id = $id;
 
// read the details of product to be edited
$teks->readOne();

 // set page header
$page_title = "Edit Teks";
include_once "header.php";

// contents will be here
echo "<div class='right-button-margin'>";
echo "<a href='index.php' class='btn btn-default pull-right'>Home</a>";
echo "</div>";
?>

<?php 
if($_POST){
 
    $teks->teks = strtoupper($_POST['teks']);
    $teks->tanggal = $_POST['tanggal'];
    $teks->status = $_POST['status'];
 
    if($teks->update()){
        echo "<div class='alert alert-success alert-dismissable'>";
            echo "Teks Telah Diubah.";
        echo "</div>";
    }
 
    else{
        echo "<div class='alert alert-danger alert-dismissable'>";
            echo "Gagal mengedit.";
        echo "</div>";
    }
}
?>
<form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"] . "?id={$id}");?>" method="post" enctype="multipart/form-data">
    <table class='table table-hover table-responsive table-bordered'>
 
         <tr>
            <td>Teks</td>
            <td colspan ='2'><textarea name='teks' class='form-control'><?= $teks->teks; ?></textarea></td>
        </tr>
    
        <tr>
        <td>Tanggal Berakhir</td>
        <td colspan = '2'>
        <div class="form-group">  
                       
                <div class="input-group date form_date col-md-5" data-date="" data-date-format="yyyy-mm-dd" data-link-field="dtp_input1" data-link-format="yyyy-mm-dd">
                    <input class="form-control" size="10" type="text" name="tanggal" value="<?php echo $teks->tanggal; ?>">
                        <span class="input-group-addon"><span class="glyphicon glyphicon-calendar">V</span></span>
                </div>
                <input type="hidden" id="dtp_input1" value=""/> 
              
            </div></td>
        </tr>
       
        <tr>
    
        <tr>
        <td>Status</td>
        <td colspan='2'>
        <?php 
        if($teks->status == 1){
            ?>
        <select class='form-control' name='status'>
                <option value='1' selected>Aktif</option>
                <option value='0'>Tidak Aktif</option>
                <?php 
        }else{
            ?><select class='form-control' name='status'>
            <option value='1' >Aktif</option>
            <option value='0' selected>Tidak Aktif</option>
            <?php 
        }
        ?>
            </select>
            </td>
            </tr>
 
        <tr>
            <td></td>
            <td>
                <button type="submit" class="btn btn-primary">Update</button>
            </td>
        </tr>
 
    </table>
</form>
<?php
 

// set page footer
include_once "footer.php";
?>