
    <!-- Bootstrap CSS -->
    <link href="libs/css/bootstrap.min.css" rel="stylesheet">
    <!-- Animate CSS -->
    <link href="libs/vendors/animate/animate.css" rel="stylesheet">
    <!-- Icon CSS-->
	<link rel="stylesheet" href="libs/vendors/font-awesome/css/font-awesome.min.css">
    <!-- Camera Slider -->
    <link rel="stylesheet" href="libs/vendors/camera-slider/camera.css">
    <!-- Owlcarousel CSS-->
	<link rel="stylesheet" type="text/css" href="libs/vendors/owl_carousel/owl.carousel.css" media="all">
    <!-- jQuery JS -->
    <script src="libs/js/jquery-1.12.0.min.js"></script>
    <!-- Bootstrap JS -->
    <script src="libs/js/bootstrap.min.js"></script>
    <!-- Animate JS -->
    <script src="libs/vendors/animate/wow.min.js"></script>
    <!-- Camera Slider -->
    <script src="libs/vendors/camera-slider/jquery.easing.1.3.js"></script>
    <script src="libs/vendors/camera-slider/camera.min.js"></script>
    <!-- Isotope JS -->
    <script src="libs/vendors/isotope/imagesloaded.pkgd.min.js"></script>
    <script src="libs/vendors/isotope/isotope.pkgd.min.js"></script>
    <!-- Progress JS -->
    <script src="libs/vendors/Counter-Up/jquery.counterup.min.js"></script>
    <script src="libs/vendors/Counter-Up/waypoints.min.js"></script>
    <!-- Owlcarousel JS -->
    <script src="libs/vendors/owl_carousel/owl.carousel.min.js"></script>
    <!-- Stellar JS -->
    <script src="libs/vendors/stellar/jquery.stellar.js"></script>
    <!-- Map JS -->
    <script src="libs/vendors/map/topbuilder_map.min.js"></script>
    <!-- Theme JS -->
    <script src="libs/js/theme.js"></script>
    