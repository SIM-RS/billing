</div>
<script src="../libs/jquery/jquery-3.2.1.min.js"></script>
 
 <script src="../libs/css/bootstrap.min.js"></script>
   
 <script src="../libs/css/bootbox.min.js"></script>
 <script type="text/javascript" src="../libs/jquery/jquery-1.8.3.min.js" charset="UTF-8"></script>
 <script type="text/javascript" src="../libs/js/bootstrap.min.js"></script>
 <script type="text/javascript" src="../libs/js/bootstrap-datetimepicker.js" charset="UTF-8"></script>
 <script type="text/javascript" src="../libs/js/locales/bootstrap-datetimepicker.id.js" charset="UTF-8"></script>
 <link href="../libs/css/bootstrap.min.css" rel="stylesheet" media="screen">
     <link href="../libs/bootstrap-datetimepicker.min.css" rel="stylesheet" media="screen">
   
<script>
$(document).on('click', '.delete-object', function(){
 
    var id = $(this).attr('delete-id');
 
    bootbox.confirm({
        message: "<h4>Are you sure?</h4>",
        buttons: {
            confirm: {
                label: '<span class="glyphicon glyphicon-ok"></span> Yes',
                className: 'btn-danger'
            },
            cancel: {
                label: '<span class="glyphicon glyphicon-remove"></span> No',
                className: 'btn-primary'
            }
        },
        callback: function (result) {
 
            if(result==true){
                $.post('hapus_event.php', {
                    object_id: id
                }, function(data){
                    location.reload();
                }).fail(function() {
                    alert('Unable to delete.');
                });
            }
        }
    });
 
    return false;
});
</script>
<script>
jQuery(function()
{		
	function getAll()
	{
		$.ajax({
			url: 'konten.php',
			data: 'status=show-all',
			cache: false,
			success: function(response){
				$("#show-product").html(response);
			}
		});			
	}
	

	$("#status").change(function()
	{				
		var id = $(this).find(":selected").val();
		var dataString = 'status='+ id;
				
		$.ajax({
			url: 'konten.php',
			data: dataString,
			cache: false,
			success: function(response){
				$("#show-product").html(response);
			} 
		});
	})
});
</script>
<script type="text/javascript">
 $('.form_date').datetimepicker({
        language:  'id',
        weekStart: 1,
        todayBtn:  1,
  autoclose: 1,
  todayHighlight: 1,
  startView: 2,
  minView: 2,
  forceParse: 0
    });
</script>
</body>
</html>