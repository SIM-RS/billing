<?php

$page_title = "Selamat Datang di Menu Display RSPHCM";
 
 
?>
<!DOCTYPE html>
<html lang="en">
<head>
 
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
 
    <title><?php echo $page_title; ?></title>

    <!-- Latest compiled and minified Bootstrap CSS -->
    <link rel="stylesheet" href="libs/css/bootstrap.min.css" />
  
    <!-- our custom CSS -->
    <link rel="stylesheet" href="libs/css/custom.css" />
  
</head>
<body>
 
    <!-- container -->
    <div class="container">
 
        <?php
        // show page header
        echo "<div class='page-header'>
                <h1>{$page_title}</h1>
            </div>";
        ?>

 
<div class='right-button-margin'>
    
    <a href='slider.php' class='btn btn-primary pull-right'>
        <span class='glyphicon glyphicon-plus'></span> Display
    </a>
</div>
 
 
    <table class='table table-hover table-responsive table-bordered'>
        <tr>
            <th><a href='event/index.php' class='btn btn-primary pull-right'>
                    <span class='glyphicon glyphicon-plus'></span> Menu Display
                </a></th>
            <th><a href='teks/index.php' class='btn btn-primary '>
                    <span class='glyphicon glyphicon-plus'></span> Running Teks
                </a></th>
        </tr>
 
 
 
    </table>
    </div>
 
 <script src=libs/jquery/jquery-3.2.1.min.js"></script>
  
 <script src="libs/css/bootstrap.min.js"></script>
   
 <script src="libs/css/bootbox.min.js"></script>
 <script type="text/javascript" src="libs/jquery/jquery-1.8.3.min.js" charset="UTF-8"></script>
 <script type="text/javascript" src="libs/js/bootstrap.min.js"></script>
 <script type="text/javascript" src="libs/js/bootstrap-datetimepicker.js" charset="UTF-8"></script>
 <script type="text/javascript" src="libs/js/locales/bootstrap-datetimepicker.id.js" charset="UTF-8"></script>
 <link href="libs/css/bootstrap.min.css" rel="stylesheet" media="screen">
     <link href="libs/bootstrap-datetimepicker.min.css" rel="stylesheet" media="screen">
    
 <script>
 $(document).on('click', '.delete-object', function(){
  
     var id = $(this).attr('delete-id');
  
     bootbox.confirm({
         message: "<h4>Are you sure?</h4>",
         buttons: {
             confirm: {
                 label: '<span class="glyphicon glyphicon-ok"></span> Yes',
                 className: 'btn-danger'
             },
             cancel: {
                 label: '<span class="glyphicon glyphicon-remove"></span> No',
                 className: 'btn-primary'
             }
         },
         callback: function (result) {
  
             if(result==true){
                 $.post('hapus_event.php', {
                     object_id: id
                 }, function(data){
                     location.reload();
                 }).fail(function() {
                     alert('Unable to delete.');
                 });
             }
         }
     });
  
     return false;
 });
 </script>
 <script type="text/javascript">
  $('.form_date').datetimepicker({
         language:  'id',
         weekStart: 1,
         todayBtn:  1,
   autoclose: 1,
   todayHighlight: 1,
   startView: 2,
   minView: 2,
   forceParse: 0
     });
 </script>
 </body>
 </html>
 