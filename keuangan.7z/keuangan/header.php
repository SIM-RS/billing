<script src="Scripts/AC_RunActiveContent.js" type="text/javascript"></script>
<table bgcolor="#1FE23E" id="Table_01" width="1000" border="0" cellpadding="0" cellspacing="0">
	<tr background="http://<?php echo $_SERVER['HTTP_HOST']?><?php echo $base_addr; ?>/images/header_03.png" >
		<td><img src="http://<?php echo $_SERVER['HTTP_HOST']?><?php echo $base_addr; ?>/images/Keu_01.png" /></td>
  </tr>
	<tr>
		<td colspan="5" width="1000" valign="top">
			<?php include ("menu.php");?></td>
	</tr>
</table>
