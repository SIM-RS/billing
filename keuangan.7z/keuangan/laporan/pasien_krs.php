<?php
	include('../koneksi/konek.php');
	//================================ PARAMETER ================================
	$wkttgl=gmdate('d/m/Y',mktime(date('H')+7));
	$wktnow=gmdate('H:i:s',mktime(date('H')+7));
	$arrBln = array('01'=>'Januari','02'=>'Februari', '03'=>'Maret', '04'=>'April', '05'=>'Mei', '06'=>'Juni','07'=>'Juli','08'=>'Agustus','09'=>'September','10'=>'Oktober','11'=>'Nopember','12'=>'Desember');
	$kso = $_REQUEST['cmbKsoRep'];
	$waktu = $_REQUEST['cmbWaktu'];
	$cwaktu=$waktu;
	//===========================================================================
	
	if($waktu == 'Harian'){
        $tglAwal = explode('-',$_REQUEST['tglAwal2']);
        $tglAwal2 = $tglAwal[2].'-'.$tglAwal[1].'-'.$tglAwal[0];
		$tglAkhir2 = $tglAwal2;
        $waktu = " AND kp.tglP = '$tglAwal2' ";
        
        $Periode = "Tanggal : ".$tglAwal[0]." ".$arrBln[$tglAwal[1]]." ".$tglAwal[2];
    }else if($waktu == 'Bulanan'){
        $bln = $_REQUEST['cmbBln'];
        $thn = $_REQUEST['cmbThn'];
		$cbln = ($bln<10)?"0".$bln:$bln;
        //$waktu = "month(t.tgl) = '$bln' AND year(t.tgl) = '$thn' ";
		$tglAwal2 = "$thn-$cbln-01";
		$tglAkhir2 = "$thn-$cbln-".cal_days_in_month(CAL_GREGORIAN, $bln, $thn);
		$waktu = " AND kp.tglP between '$tglAwal2' and '$tglAkhir2' ";
		
        $Periode = "Bulan $arrBln[$cbln] Tahun $thn";
		//$tglAkhir2="$thn-$cbln-".cal_days_in_month(CAL_GREGORIAN, $bln, $thn);
		//$tglAwal2="$thn-$cbln-01";
    }else{
        $tglAwal = explode('-',$_REQUEST['tglAwal']);
        $tglAwal2 = $tglAwal[2].'-'.$tglAwal[1].'-'.$tglAwal[0];
        //echo $_REQUEST['tglAkhir'];
        $tglAkhir = explode('-',$_REQUEST['tglAkhir']);
        $tglAkhir2 = $tglAkhir[2].'-'.$tglAkhir[1].'-'.$tglAkhir[0];
        $waktu = " AND kp.tglP between '$tglAwal2' and '$tglAkhir2' ";
        
        $Periode = "Periode : ".$tglAwal[0]." ".$arrBln[$tglAwal[1]]." ".$tglAwal[2].' s/d '.$tglAkhir[0]." ".$arrBln[$tglAkhir[1]]." ".$tglAkhir[2];
    }
	
	if($kso == 0){
		$fkso = "SEMUA";
		$nKso = $fkso = "";
	} else {
		$fkso = " AND kp.kso_id = '{$kso}'";
		$qKso = "SELECT billing.b_ms_kso.id, billing.b_ms_kso.nama FROM billing.b_ms_kso
			WHERE billing.b_ms_kso.id = '".$kso."'";
		$sKso = mysql_query($qKso);
		$dKso = mysql_fetch_array($sKso);
		$nKso = "PEMJAMIN : ".$dKso['nama']."<br />";
	}
?>
<!DOCTYPE HTML>
<html lang="en-US">
<head>
	<meta charset="UTF-8">
	<title>Laporan Piutang Pasien KRS</title>
	<style type="text/css">
		body{ margin:0px; padding:0px; font-family:Arial; font-size:12px; line-height:1.3em; }
		#container{ width:1280px; margin:10px auto; padding:0px; display:block; }
		#title{ width:100%; display:block; margin-bottom:3px; text-align:left; font-weight:bold; font-size:14px; }
		.isian{ border-collapse: collapse; margin-bottom: 10px; }
		.isian td, .isian th{ padding:5px; border:1px solid #000; }
		.isian th{ background:#E1E1E1; }
		.isian .noborder{ border:0px; }
		#des{ font-size:12px; }
		#signature{ float:right; width:300px; display:block; text-align:center; margin-bottom: 40px; }
	</style>
	<script type="text/javascript">
		function cetak(id){
			document.getElementById('cetakID').style.display="none";
			if(!window.print()){
				document.getElementById('cetakID').style.display="inline";
			}
		}
		
		function cetakExcell(){
			//window.location.href = 'lap_bkm.php?id=<?php echo $idBKM; ?>&isExcel=1';
		}
	</script>
</head>
<body>
	<center>
		<span id="cetakID" style="float:left; position:fixed; width:100%; display:block; left:0px; bottom:0px; background:#0084FF; padding:5px;"><button id="btCetak" type="button" name="btCetak" onclick="cetak()">Cetak Laporan Piutang Pasien KRS</button></span>
	</center>
	<div id="container">	
		<section style="margin-bottom:20px;">
			<b>PEMERINTAH KABUPATEN SIDOARJO<br>Rumah Sakit Umum Daerah Kabupaten Sidoarjo<br>Jl. Mojopahit 667 Sidoarjo<br>Telepon (031) 896 1649</b>
		</section>
		<header id="title">
			<center style="text-transform:uppercase; line-height:1.25em;">
				Laporan Piutang Pasien KRS<br />
				<?php echo $nKso; ?>
				<?php echo $Periode; ?><br />
				<br />
			</center>
			<span id="des"></span>
		</header>
		<section id="detail">
			<table class="isian" width="100%">
				<tr>
					<th width="10px">NO</th>
					<!--th width="80px">TANGGAL KUNJUNGAN</th-->
					<th width="80px">TANGGAL PULANG</th>
					<th width="80px">NO RM</th>
					<th >NAMA</th>
					<!--th width="120">KSO</th-->
					<!--th width="120">KUNJUNGAN AWAL</th-->
					<th width="100px">TARIF RS</th>
					<th width="100px">BIAYA PASIEN</th>
					<th width="100px">BIAYA KSO</th>
					<th width="100px">BAYAR PESIEN</th>
					<th width="100px">PIUTANG PASIEN</th>
				</tr>
				<?php
					$sql = "SELECT *
							FROM (SELECT
									  k.id, pas.no_rm, pas.nama AS pasien, kso.nama kso,
									  mu.nama unit, DATE_FORMAT(kp.tglK,'%d-%m-%Y') AS tgl,
									  DATE_FORMAT(kp.tglP,'%d-%m-%Y') AS tgl_p, kp.biayaRS,
									  kp.biayaPasien, kp.biayaKSO, kp.bayarPasien, kp.piutangPasien
									FROM k_piutang kp
									  INNER JOIN $dbbilling.b_kunjungan k
										ON kp.kunjungan_id = k.id
									  INNER JOIN $dbbilling.b_ms_pasien pas
										ON k.pasien_id = pas.id
									  INNER JOIN $dbbilling.b_ms_kso kso
										ON k.kso_id = kso.id
									  INNER JOIN $dbbilling.b_ms_unit mu
										ON k.unit_id = mu.id
									WHERE 0 = 0 {$waktu} {$fkso}
									  AND kp.tipe=0) tx
							ORDER BY tx.tgl, tx.id";
					//echo $sql;
					$query = mysql_query($sql) or die(mysql_error());
					if($query && mysql_affected_rows() > 0){
						$i = 1;
						$grandtotal = array();
						$tmpKso = '';
						$subtotal = array();
						while ($rows=mysql_fetch_array($query)) {
							$tPerda=$rows["biayaRS"]+$rows["kamarRS"];
							$tKSO=$rows["biayaKSO"]+$rows["kamarKSO"];
							$tPx=$rows["biayaPasien"]+$rows["kamarPasien"];
							$tBayarPx=$rows["bayarPasien"]+$rows["bayarKamarPasien"];
							$tPiutangPx=$tPx-$tBayarPx;
							
							if($rows["kso"] != $tmpKSO){
								if($i > 1){
									echo "<tr>
											<td align='right' colspan='4'>SubTotal</td>
											<td align='right'>".number_format($subtotal['perda'],0,",",".")."</td>
											<td align='right'>".number_format($subtotal['px'],0,",",".")."</td>
											<td align='right'>".number_format($subtotal['kso'],0,",",".")."</td>
											<td align='right'>".number_format($subtotal['bayarpx'],0,",",".")."</td>
											<td align='right'>".number_format($subtotal['piutang'],0,",",".")."</td>
										</tr>";
								}
								echo "<tr>
									<td colspan='9' style='color:blue; font-weight:bold;'>".$rows["kso"]."</td>
								</tr>";
								
								$i = 1;
								$tmpKSO = $rows["kso"];
								$subtotal = array();
							}
							
							echo "<tr>
									<td align='center'>".$i++."</td>
									<!--td align='center'>".$rows["tgl"]."</td-->
									<td align='center'>".$rows["tgl_p"]."</td>
									<td align='center'>".$rows["no_rm"]."</td>
									<td>".$rows["pasien"]."</td>
									<!--td>".$rows["kso"]."</td-->
									<!--td>".$rows["unit"]."</td-->
									<td align='right'>".number_format($tPerda,0,",",".")."</td>
									<td align='right'>".number_format($tPx,0,",",".")."</td>
									<td align='right'>".number_format($tKSO,0,",",".")."</td>
									<td align='right'>".number_format($tBayarPx,0,",",".")."</td>
									<td align='right'>".number_format($tPiutangPx,0,",",".")."</td>
								</tr>";
							
							$subtotal['perda'] += $tPerda;
							$subtotal['px'] += $tPx;
							$subtotal['kso'] += $tKSO;
							$subtotal['bayarpx'] += $tBayarPx;
							$subtotal['piutang'] += $tPiutangPx;
							
							$grandtotal['perda'] += $tPerda;
							$grandtotal['px'] += $tPx;
							$grandtotal['kso'] += $tKSO;
							$grandtotal['bayarpx'] += $tBayarPx;
							$grandtotal['piutang'] += $tPiutangPx;
						}
					} else {
						echo "<tr>
							<td colspan='12' align='center' style='font-weight:bold; font-size:14px; padding:10px;'>Tidak Ada Data dalam Periode ini.</td>
						</tr>";
					}
					echo "<tr>
							<td align='right' colspan='4'>SubTotal</td>
							<td align='right'>".number_format($subtotal['perda'],0,",",".")."</td>
							<td align='right'>".number_format($subtotal['px'],0,",",".")."</td>
							<td align='right'>".number_format($subtotal['kso'],0,",",".")."</td>
							<td align='right'>".number_format($subtotal['bayarpx'],0,",",".")."</td>
							<td align='right'>".number_format($subtotal['piutang'],0,",",".")."</td>
						</tr>";
					echo "<tr style='font-weight:bold;'>
							<td align='right' colspan='4'>Total</td>
							<td align='right'>".number_format($grandtotal['perda'],0,",",".")."</td>
							<td align='right'>".number_format($grandtotal['px'],0,",",".")."</td>
							<td align='right'>".number_format($grandtotal['kso'],0,",",".")."</td>
							<td align='right'>".number_format($grandtotal['bayarpx'],0,",",".")."</td>
							<td align='right'>".number_format($grandtotal['piutang'],0,",",".")."</td>
						</tr>";
				?>
			</table>
			<div id="signature">
				<p>Sidoarjo, <?=$wkttgl.' '.$wktnow;?></p>
			</div>
		</section>
</body>
</html>