<?php
$idTrans_PenerimaanBilling_Kasir = 38;
$idTrans_Penerimaan_Kasir_Farmasi = 39;
?>