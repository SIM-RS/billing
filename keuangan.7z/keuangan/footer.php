
<table id="Table_01" width="1000" height="49" border="0" cellpadding="0" cellspacing="0">
	<tr>
		<td style="background:#33CC33;
				/* url('http://<?php echo $_SERVER['HTTP_HOST'];?><?php echo $base_addr; ?>/images/feature_02.jpg') repeat */">&nbsp;
			<div id="copyright" style="display:none">Copyright &copy; 2010 <a href="http://apycom.com/">Apycom jQuery Menus</a></div>
		</td>
	</tr>
</table>
