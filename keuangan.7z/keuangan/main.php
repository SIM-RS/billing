
<!-- ImageReady Slices (Keuangan_04.gif) -->
<table id="Table_01" width="1000" height="414" border="0" cellpadding="0" cellspacing="0">
	<tr>
		<td colspan="7" bgcolor="#EAEFF3" width="1000" height="414">&nbsp;</td>
  </tr>

	
	
	
	
	
	



	<tr>
		<td>
			<img src="images/spacer.gif" width="319" height="1" alt=""></td>
		<td>
			<img src="images/spacer.gif" width="24" height="1" alt=""></td>
		<td>
			<img src="images/spacer.gif" width="91" height="1" alt=""></td>
		<td>
			<img src="images/spacer.gif" width="82" height="1" alt=""></td>
		<td>
			<img src="images/spacer.gif" width="95" height="1" alt=""></td>
		<td>
			<img src="images/spacer.gif" width="26" height="1" alt=""></td>
		<td>
			<img src="images/spacer.gif" width="363" height="1" alt=""></td>
	</tr>
</table>
