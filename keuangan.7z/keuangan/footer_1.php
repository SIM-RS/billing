
<table id="Table_01" width="1000" height="49" border="0" cellpadding="0" cellspacing="0">
	<tr>
		<td rowspan="3">
			<img src="http://<?php echo $_SERVER['HTTP_HOST']?><?php echo $base_addr; ?>/images/footer1_01.jpg" width="64" height="49" alt=""></td>
		<td rowspan="2">
			<img src="http://<?php echo $_SERVER['HTTP_HOST']?><?php echo $base_addr; ?>/images/footer1_02.jpg" width="73" height="33" alt=""></td>
		<td rowspan="2">
			<img src="http://<?php echo $_SERVER['HTTP_HOST']?><?php echo $base_addr; ?>/images/footer1_03.jpg" width="68" height="33" alt=""></td>
		<td rowspan="2">
			<img src="http://<?php echo $_SERVER['HTTP_HOST']?><?php echo $base_addr; ?>/images/footer1_04.jpg" width="75" height="33" alt=""></td>
		<td rowspan="2">
			<img src="http://<?php echo $_SERVER['HTTP_HOST']?><?php echo $base_addr; ?>/images/footer1_05.jpg" width="78" height="33" alt=""></td>
		<td rowspan="2">
			<img src="http://<?php echo $_SERVER['HTTP_HOST']?><?php echo $base_addr; ?>/images/footer1_06.jpg" width="83" height="33" alt=""></td>
		<td rowspan="2">
			<img src="http://<?php echo $_SERVER['HTTP_HOST']?><?php echo $base_addr; ?>/images/footer1_07.jpg" width="98" height="33" alt=""></td>
		<td rowspan="2">
			<img src="http://<?php echo $_SERVER['HTTP_HOST']?><?php echo $base_addr; ?>/images/footer1_08.jpg" width="77" height="33" alt=""></td>
		<td rowspan="2" width="227" height="33" background="http://<?php echo $_SERVER['HTTP_HOST']?><?php echo $base_addr; ?>/images/footer1_09.jpg">
			</td>
		<td>
			<img src="http://<?php echo $_SERVER['HTTP_HOST']?><?php echo $base_addr; ?>/images/footer1_10.jpg" width="156" height="25" alt=""></td>
		<td>
			<img src="http://<?php echo $_SERVER['HTTP_HOST']?><?php echo $base_addr; ?>/images/spacer.gif" width="1" height="25" alt=""></td>
	</tr>
	<tr>
		<td rowspan="2">
			<img src="http://<?php echo $_SERVER['HTTP_HOST']?><?php echo $base_addr; ?>/images/footer1_11.png" width="156" height="24" alt=""></td>
		<td>
			<img src="http://<?php echo $_SERVER['HTTP_HOST']?><?php echo $base_addr; ?>/images/spacer.gif" width="1" height="8" alt=""></td>
	</tr>
	<tr>
		<td colspan="7">
			<img src="http://<?php echo $_SERVER['HTTP_HOST']?><?php echo $base_addr; ?>/images/footer1_12.jpg" width="552" height="16" alt=""></td>
		<td width="219" height="16">
			<img src="http://<?php echo $_SERVER['HTTP_HOST']?><?php echo $base_addr; ?>/images/footer1_13.jpg" width="227" height="16" alt=""></td>
		<td>
			<img src="http://<?php echo $_SERVER['HTTP_HOST']?><?php echo $base_addr; ?>/images/spacer.gif" width="1" height="16" alt=""></td>
	</tr>
</table>
