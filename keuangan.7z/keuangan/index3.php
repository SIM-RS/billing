<html>
<head>
<title>Keuangan</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link rel="stylesheet" type="text/css" href="style2.css" media="screen" />
</head>
<div align="center">
<body bgcolor="#FFFFFF" leftmargin="0" topmargin="0" marginwidth="0" marginheight="0">
<!-- ImageReady Slices (Keuangan.psd) -->
<table id="Table_01" width="1000" height="658" border="0" cellpadding="0" cellspacing="0">
	<tr>
		<td colspan="2" width="1000" height="96">
			<?php include ("h1.php");?></td>
	</tr>
    <tr>
		<td valign="top" colspan="2" width="1000"><?php include ("main.php");?><?php include ("footer.php");?></td>
	</tr>

</table>
<!-- End ImageReady Slices -->
</body>
</div>
</html>