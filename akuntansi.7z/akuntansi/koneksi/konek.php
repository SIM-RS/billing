<?php
//$hostname_conn = "localhost";
//$hostname_conn = "172.16.1.120";
$hostname_conn = "127.0.0.1";
$database_conn = "rspelindo_akuntansi";
//$database_conn = "simkeu5";
$username_conn = "root";
//$username_conn = "admindb_kadal";
$password_conn = "rspm@2016";

$dbakuntansi = $database_conn;
$dbapotek = "rspelindo_apotek";
$dbbilling = "rspelindo_billing";
$dbkeuangan = "rspelindo_keuangan";
$dbaset = "rspelindo_asset";
$dbanggaran = "rspelindo_anggaran";
$base_addr="/simrs-pelindo/akuntansi";

$konek=mysql_connect($hostname_conn,$username_conn,$password_conn);
mysql_select_db($database_conn,$konek);

$perpage=100;

if (!function_exists('tglSQL')){
function tglSQL($tgl){
   $t=explode(" ",$tgl);
   $t=explode("-",$t[0]);
   $t=$t[2].'-'.$t[1].'-'.$t[0];
   return $t;
}
}

if (!function_exists('tglJamSQL')){
function tglJamSQL($tgl){
   $dateTime=explode(" ",$tgl);
   $dateTime=tglSQL($dateTime[0])." ".$dateTime[1];
   return $dateTime;
}
}

if (!function_exists('kekata')){ 
function kekata($x) {
  $x = abs($x);
  $angka = array("", "satu", "dua", "tiga", "empat", "lima",
  "enam", "tujuh", "delapan", "sembilan", "sepuluh", "sebelas");
  $temp = "";
  if ($x <12) {
	  $temp = " ". $angka[$x];
  } else if ($x <20) {
	  $temp = kekata($x - 10). " belas";
  } else if ($x <100) {
	  $temp = kekata($x/10)." puluh". kekata($x % 10);
  } else if ($x <200) {
	  $temp = " seratus" . kekata($x - 100);
  } else if ($x <1000) {
	  $temp = kekata($x/100) . " ratus" . kekata($x % 100);
  } else if ($x <2000) {
	  $temp = " seribu" . kekata($x - 1000);
  } else if ($x <1000000) {
	  $temp = kekata($x/1000) . " ribu" . kekata($x % 1000);
  } else if ($x <1000000000) {
	  $temp = kekata($x/1000000) . " juta" . kekata($x % 1000000);
  } else if ($x <1000000000000) {
	  $temp = kekata($x/1000000000) . " milyar" . kekata(fmod($x,1000000000));
  } else if ($x <1000000000000000) {
	  $temp = kekata($x/1000000000000) . " trilyun" . kekata(fmod($x,1000000000000));
  }      
	  return $temp;
}
}

if (!function_exists('terbilang')){ 
function terbilang($x, $style=4) {
  if($x<0) {
	  $hasil = "minus ". trim(kekata($x));
  } else {
	  $hasil = trim(kekata($x));
  }      
  switch ($style) {
	  case 1:
		  $hasil = strtoupper($hasil);
		  break;
	  case 2:
		  $hasil = strtolower($hasil);
		  break;
	  case 3:
		  $hasil = ucwords($hasil);
		  break;
	  default:
		  $hasil = ucfirst($hasil);
		  break;
  }      
  return $hasil;
}
}
?>
