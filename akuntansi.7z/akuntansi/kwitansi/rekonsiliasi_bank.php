<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>.: Rekonsiliasi Bank :.</title>
</head>

<body>
<form>
  <table align="left" width="800" border="0" cellspacing="0" cellpadding="0" style="font-family:Arial, Helvetica, sans-serif; font-size:12px;">
    <tr>
      <td><b>RSUD KOTA TANGERANG<br />
        Jl. Jendral Sudirman No.101 Tangerang
         <br/></b>
      </td>
    </tr><tr>
      <td align="center" height="50" valign="top" style="font-weight:bold; font-size:16px; text-transform:uppercase">REKONSILIASI BANK</td>
    </tr><tr>
      <td align="right" valign="top" style="font-family:Arial; font-weight:bold; font-size:12px">Nama Bank :</td>
    </tr><tr>
      <td align="right" valign="top" style="font-family:Arial; font-weight:bold; font-size:12px">Nomor Rekening :</td>
    </tr><tr>
      <td height="70" style="font-weight:bold">Per Tanggal : </td>
    </tr><tr>
      <td>
  <table width="100%" border="1" cellpadding="0" cellspacing="0" style="border-collapse:collapse">
	<tr>
		<td height="30" width="4%" style="border-bottom:#000000 solid 1px; border-top:#000000 1px solid; font-weight:bold; text-align:center;">NO</td>
		<td width="40%" style="border-bottom:#000000 solid 1px; border-top:#000000 1px solid; font-weight:bold; text-align:center;">URAIAN</td>
		<td width="30%" style="border-bottom:#000000 solid 1px; border-top:#000000 1px solid; font-weight:bold; text-align:center;">BUKU BANK</td>
		<td width="26%" style="border-bottom:#000000 solid 1px; border-top:#000000 1px solid; font-weight:bold; text-align:center;">RK BANK</td>
	</tr><tr>
        <td style="text-align:center;">&nbsp;</td>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
	</tr><tr>
        <td style="text-align:center;">&nbsp;</td>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
	</tr><tr>
        <td style="text-align:center;">1</td>
        <td>Saldo sebelum rekosiliasi </td>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
	</tr><tr>
        <td style="text-align:center;">&nbsp;</td>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
	</tr><tr>
        <td style="text-align:center;">2</td>
        <td>Rekonsiliasi :</td>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
	</tr><tr>
        <td style="text-align:center;">&nbsp;</td>
        <td>Cek dalam peredaran</td>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
	</tr><tr>
        <td style="text-align:center;">&nbsp;</td>
        <td>Setoran dalam perjalanan</td>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
    </tr><tr>
        <td style="text-align:center;">&nbsp;</td>
        <td>Jasa Giro</td>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
	</tr><tr>
        <td style="text-align:center;">&nbsp;</td>
        <td>PPh Jasa Giro</td>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
	</tr><tr>
        <td style="text-align:center;">&nbsp;</td>
        <td>Biaya Admibistrasi Bank</td>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
    </tr><tr>
        <td style="text-align:center;">&nbsp;</td>
        <td align="center">Jumlah Rekonsiliasi (2)</td>
        <td style="border-bottom:#000000 solid 2px; border-left:#000000 solid 2px; border-right:#000000 solid 2px; border-top:#000000 2px solid; font-weight:bold; text-align:right;">-&nbsp;</td>
        <td style="border-bottom:#000000 solid 2px; border-right:#000000 solid 2px; border-left:#000000 solid 2px; border-top:#000000 2px solid; font-weight:bold; text-align:right;">-&nbsp;</td>
	</tr><tr>
        <td style="text-align:center;">&nbsp;</td>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
	</tr><tr>
        <td style="text-align:center;">3</td>
        <td>Saldo rekosiliasi</td>
        <td align="right"><strong>-</strong></td>
        <td align="right"><strong>-</strong></td>
    </tr>
</table>
<table width="1092">
	<tr height="30">
        <td>&nbsp;</td>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
    </tr>
    <tr height="30">
        <td width="89">&nbsp;</td>
        <td width="113">&nbsp;</td>
        <td width="484">&nbsp;</td>
        <td width="176" align="center">Diperiksa</td>
        <td width="48">&nbsp;</td>
        <td width="182" align="center">Yang Membuat</td>
        <td width="26">&nbsp;</td>
	</tr><tr height="30">
        <td>&nbsp;</td>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
        <td align="center">&nbsp;</td>
        <td>&nbsp;</td>
        <td align="center">&nbsp;</td>
        <td>&nbsp;</td>
	 </tr><tr height="30">
		  <td>&nbsp;</td>
		  <td>&nbsp;</td>
		  <td>&nbsp;</td>
		  <td align="center">&nbsp;</td>
		  <td>&nbsp;</td>
		  <td align="center">&nbsp;</td>
		  <td>&nbsp;</td>
	  </tr><tr height="30">
		  <td>&nbsp;</td>
		  <td>&nbsp;</td>
		  <td>&nbsp;</td>
		  <td align="center">&nbsp;</td>
		  <td>&nbsp;</td>
		  <td align="center">&nbsp;</td>
		  <td>&nbsp;</td>
	  </tr><tr height="30">
          <td>&nbsp;</td>
          <td>&nbsp;</td>
          <td>&nbsp;</td>
          <td align="center" style="border-bottom:#000000 solid 1px;">&nbsp;</td>
          <td>&nbsp;</td>
          <td align="center" style="border-bottom:dotted"></td>
          <td>&nbsp;</td>
	</tr>
</table>
</form>
</body>
</html>