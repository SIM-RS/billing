<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN""http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>.:BERITA ACARA PERHITUNGAN KAS KECIL:.</title>
</head>

<body>
<form>
  <table width="100%">
    <tr>
      <td align="left"><strong>RSUD KOTA TANGERANG</strong></td>
    </tr><tr>
      <td align="left"><strong>Jl. Jendral Sudirman No.101 Tangerang</strong></td>
  </tr><tr>
      <td height="30" colspan="3" align="center" style="font-size:14px;font-weight:bold;">BERITA ACARA PERHITUNGAN KAS KECIL</td>
  </tr><tr>  
      <td colspan="3" align="center" style="font-size:14px;">Pada hari ini, ........................... Tanggal ........................ Tahun ........................ Telah dilakukan perhitungan kas kecil dengan hasil sebagai berikut :</td>
  </tr>
  </table>
  <table width="94%" border="0" cellpadding="0" cellspacing="0">
    <tr>
      <td colspan="4" align="left">Terdiri dari :</td>
      <td align="center">&nbsp;</td>
      <td align="center"></td>
      <td align="center">&nbsp;</td>
      <td align="center">&nbsp;</td>
      <td align="center"></td>
      <td align="center"></td>
      <td align="center">&nbsp;</td>
      <td align="center">&nbsp;</td>
      <td align="center"></td>
      <td align="center"></td>
      <td align="center"></td>
      <td align="center"></td>
      <td align="center"></td>
      <td align="center"></td>
      <td align="center"></td>
      <td align="center"></td>
    </tr>
    <tr>
      <td align="center">&nbsp;</td>
      <td align="left">&nbsp;</td>
      <td colspan="2" align="left">&nbsp;</td>
      <td align="left"></td>
      <td align="center"></td>
      <td align="left"></td>
      <td align="left"></td>
      <td align="center"></td>
      <td align="center"></td>
      <td align="left"></td>
      <td align="left"></td>
      <td align="center"></td>
      <td align="center"></td>
      <td align="center"></td>
      <td align="center"></td>
      <td align="center"></td>
      <td align="center"></td>
      <td align="center"></td>
      <td align="center"></td>
    </tr>
    <tr>
      <td align="center">&nbsp;</td>
      <td align="left"><strong>1</strong></td>
      <td colspan="2" align="left"><strong>Uang Kertas :</strong></td>
      <td align="left"></td>
      <td align="center"></td>
      <td align="left"></td>
      <td align="left"></td>
      <td align="center"></td>
      <td align="center"></td>
      <td align="left"></td>
      <td align="left"></td>
      <td align="center"></td>
      <td align="center"></td>
      <td align="center"></td>
      <td align="center"></td>
      <td align="center"></td>
      <td align="center"></td>
      <td align="center"></td>
      <td align="center"></td>
    </tr><tr>
      <td align="center" width="25">&nbsp;</td>
      <td align="left" width="51">&nbsp;</td>
      <td colspan="2" align="left">&nbsp;</td>
      <td align="left" width="4"></td>
      <td align="center" width="145"></td>
      <td align="left" width="4"></td>
      <td align="left" width="116"></td>
      <td align="center" width="12"></td>
      <td align="center" width="158"></td>
      <td align="left" width="73"></td>
      <td align="left" width="286"></td>
      <td align="center" width="40"></td>
      <td align="center" width="55"></td>
      <td align="center" width="7"></td>
      <td align="center" width="4"></td>
      <td align="center" width="4"></td>
      <td align="center" width="27"></td>
      <td align="center" width="14"></td>
      <td align="center" width="94"></td>
   </tr><tr>
      <td align="center" width="25">&nbsp;</td>
      <td align="center">&nbsp;</td>
      <td align="left" width="56">&nbsp;</td>
      <td align="left" width="80">Rp. 100.000</td>
      <td align="center"></td>
      <td align="center" width="145"></td>
      <td align="center"></td>
      <td align="center">&nbsp;</td>
      <td align="center"></td>
      <td align="center">.....................</td>
      <td align="center" width="73"><strong>Lembar</strong></td>
      <td align="center"></td>
      <td align="center" width="40"></td>
      <td align="center" width="55"></td>
      <td align="center" width="7"></td>
      <td align="center" width="4"></td>
      <td align="center" width="4"></td>
      <td align="right" width="27">Rp.</td>
      <td align="center" width="14"></td>
      <td align="center" width="94"></td>
  </tr><tr>
      <td align="center">&nbsp;</td>
      <td align="center">&nbsp;</td>
      <td align="left" width="56">&nbsp;</td>
      <td align="left">Rp. 50.000</td>
      <td align="center"></td>
      <td align="center"></td>
      <td align="center"></td>
      <td align="center">&nbsp;</td>
      <td align="center">&nbsp;</td>
      <td align="center">.....................</td>
      <td align="center"><strong>Lembar</strong></td>
      <td align="center"></td>
      <td align="center"></td>
      <td align="center"></td>
      <td align="center"></td>
      <td align="center"></td>
      <td align="center"></td>
      <td align="right">Rp.</td>
      <td align="center"></td>
      <td align="center"></td>
  </tr><tr>
      <td align="center" width="25">&nbsp;</td>
      <td align="center">&nbsp;</td>
      <td align="left" width="56">&nbsp;</td>
      <td align="left" width="80">Rp. 20.000</td>
      <td align="center"></td>
      <td align="center" width="145"></td>
      <td align="center"></td>
      <td align="center">&nbsp;</td>
      <td align="center">&nbsp;</td>
      <td align="center">.....................</td>
      <td align="center" width="73"><strong>Lembar</strong></td>
      <td align="center"></td>
      <td align="center" width="40"></td>
      <td align="center" width="55"></td>
      <td align="center" width="7"></td>
      <td align="center" width="4"></td>
      <td align="center" width="4"></td>
      <td align="right" width="27">Rp.</td>
      <td align="center" width="14"></td>
      <td align="center" width="94"></td>
  </tr><tr>
      <td align="center" width="25">&nbsp;</td>
      <td align="center">&nbsp;</td>
      <td align="left" width="56">&nbsp;</td>
      <td align="left" width="80">Rp. 10.000</td>
      <td align="center"></td>
      <td align="center" width="145"></td>
      <td align="center"></td>
      <td align="center">&nbsp;</td>
      <td align="center">&nbsp;</td>
      <td align="center">.....................</td>
      <td align="center" width="73"><strong>Lembar</strong></td>
      <td align="center"></td>
      <td align="center" width="40"></td>
      <td align="center" width="55"></td>
      <td align="center" width="7"></td>
      <td align="center" width="4"></td>
      <td align="center" width="4"></td>
      <td align="right" width="27">Rp.</td>
      <td align="center" width="14"></td>
      <td align="center" width="94"></td>
  </tr><tr>
      <td align="center">&nbsp;</td>
      <td align="center">&nbsp;</td>
      <td align="left" width="56">&nbsp;</td>
      <td align="left">Rp. 5.000</td>
      <td align="center"></td>
      <td align="center"></td>
      <td align="center"></td>
      <td align="center">&nbsp;</td>
      <td align="center">&nbsp;</td>
      <td align="center">.....................</td>
      <td align="center"><strong>Lembar</strong></td>
      <td align="center"></td>
      <td align="center"></td>
      <td align="center"></td>
      <td align="center"></td>
      <td align="center"></td>
      <td align="center"></td>
      <td align="right">Rp.</td>
      <td align="center"></td>
      <td align="center"></td>
  </tr><tr>
      <td align="center">&nbsp;</td>
      <td align="center">&nbsp;</td>
      <td align="left" width="56">&nbsp;</td>
      <td align="left">Rp. 1.000</td>
      <td align="center"></td>
      <td align="center"></td>
      <td align="center"></td>
      <td align="center">&nbsp;</td>
      <td align="center">&nbsp;</td>
      <td align="center">.....................</td>
      <td align="center"><strong>Lembar</strong></td>
      <td align="center"></td>
      <td align="center"></td>
      <td align="center"></td>
      <td align="center"></td>
      <td align="center"></td>
      <td align="center"></td>
      <td align="right">Rp.</td>
      <td align="center" style="border-bottom:#000000 solid 1px;"></td>
      <td align="center" style="border-bottom:#000000 solid 1px;"></td>
   </tr><tr>
      <td align="center">&nbsp;</td>
      <td align="center">&nbsp;</td>
      <td align="left" width="56">&nbsp;</td>
      <td align="left">&nbsp;</td>
      <td align="center"></td>
      <td align="center"></td>
      <td align="center"></td>
      <td align="center"></td>
      <td align="center"></td>
      <td align="center"></td>
      <td align="center"></td>
      <td align="center"></td>
      <td align="center"></td>
      <td align="center"></td>
      <td align="center"></td>
      <td align="center"></td>
      <td align="center"></td>
      <td align="right"></td>
      <td align="center" style="border-bottom:#000000 solid 1px;"></td>
      <td align="center" style="border-bottom:#000000 solid 1px;"></td>
  </tr><tr>
      <td align="center">&nbsp;</td>
      <td align="center">&nbsp;</td>
      <td align="center" width="56">&nbsp;</td>
      <td align="center">&nbsp;</td>
      <td align="center"></td>
      <td align="center"></td>
      <td align="center"></td>
      <td align="center">&nbsp;</td>
      <td align="center">&nbsp;</td>
      <td align="center"><strong>Jumlah (1)</strong></td>
      <td align="center"></td>
      <td align="center"></td>
      <td align="right">&nbsp;</td>
      <td align="right">&nbsp;</td>
      <td align="right">&nbsp;</td>
      <td align="right">&nbsp;</td>
      <td align="right">&nbsp;</td>
      <td align="right">Rp.</td>
      <td align="right">&nbsp;</td>
      <td align="right">&nbsp;</td>
  </tr><tr>
      <td align="center">&nbsp;</td>
      <td align="left"><strong>2</strong></td>
      <td colspan="2" align="left"><strong>Uang Logam :</strong></td>
      <td align="center"></td>
      <td align="center"></td>
      <td align="center"></td>
      <td align="center"></td>
      <td align="center"></td>
      <td align="center"></td>
      <td align="center"></td>
      <td align="center"></td>
      <td align="center"></td>
      <td align="center"></td>
      <td align="center"></td>
      <td align="center"></td>
      <td align="center"></td>
      <td align="center"></td>
      <td align="center"></td>
      <td align="center"></td>
  </tr><tr>
      <td align="center">&nbsp;</td>
      <td align="center">&nbsp;</td>
      <td align="left" width="56">&nbsp;</td>
      <td align="left">&nbsp;</td>
      <td align="center"></td>
      <td align="center"></td>
      <td align="center"></td>
      <td align="center"></td>
      <td align="center"></td>
      <td align="center"></td>
      <td align="center"></td>
      <td align="center"></td>
      <td align="center"></td>
      <td align="center"></td>
      <td align="center"></td>
      <td align="center"></td>
      <td align="center"></td>
      <td align="center"></td>
      <td align="center"></td>
      <td align="center"></td>
  </tr><tr>
      <td align="center">&nbsp;</td>
      <td align="center">&nbsp;</td>
      <td align="left" width="56">&nbsp;</td>
      <td align="left">Rp. 1.000</td>
      <td align="center"></td>
      <td align="center"></td>
      <td align="center"></td>
      <td align="center">&nbsp;</td>
      <td align="center">&nbsp;</td>
      <td align="center">.....................</td>
      <td align="center"><strong>Keping</strong></td>
      <td align="center"></td>
      <td align="center"></td>
      <td align="center"></td>
      <td align="center"></td>
      <td align="center"></td>
      <td align="center"></td>
      <td align="right" width="27">Rp.</td>
      <td align="center"></td>
      <td align="center"></td>
  </tr><tr>
      <td align="center">&nbsp;</td>
      <td align="center">&nbsp;</td>
      <td align="left" width="56">&nbsp;</td>
      <td align="left">Rp. 500</td>
      <td align="center"></td>
      <td align="center"></td>
      <td align="center"></td>
      <td align="center">&nbsp;</td>
      <td align="center">&nbsp;</td>
      <td align="center">.....................</td>
      <td align="center"><strong>Keping</strong></td>
      <td align="center"></td>
      <td align="center">&nbsp;</td>
      <td align="center">&nbsp;</td>
      <td align="center">&nbsp;</td>
      <td align="center">&nbsp;</td>
      <td align="center">&nbsp;</td>
      <td align="right">Rp.</td>
      <td align="center">&nbsp;</td>
      <td align="center">&nbsp;</td>
  </tr><tr>
      <td align="center">&nbsp;</td>
      <td align="center">&nbsp;</td>
      <td align="left" width="56">&nbsp;</td>
      <td align="left">Rp. 200</td>
      <td align="center"></td>
      <td align="center"></td>
      <td align="center"></td>
      <td align="center">&nbsp;</td>
      <td align="center">&nbsp;</td>
      <td align="center">.....................</td>
      <td align="center"><strong>Keping</strong></td>
      <td align="center"></td>
      <td align="right">&nbsp;</td>
      <td align="right">&nbsp;</td>
      <td align="right">&nbsp;</td>
      <td align="right">&nbsp;</td>
      <td align="right">&nbsp;</td>
      <td align="right" width="27">Rp.</td>
      <td align="right">&nbsp;</td>
      <td align="right">&nbsp;</td>
  </tr><tr>
      <td align="center">&nbsp;</td>
      <td align="center">&nbsp;</td>
      <td align="left" width="56">&nbsp;</td>
      <td align="left">Rp. 100</td>
      <td align="center"></td>
      <td align="center"></td>
      <td align="center"></td>
      <td align="center">&nbsp;</td>
      <td align="center">&nbsp;</td>
      <td align="center">.....................</td>
      <td align="center"><strong>Keping</strong></td>
      <td align="center"></td>
      <td align="center"></td>
      <td align="center"></td>
      <td align="center"></td>
      <td align="center"></td>
      <td align="center"></td>
      <td align="right" width="27">Rp.</td>
      <td align="center"></td>
      <td align="center"></td>
  </tr><tr>
      <td align="center">&nbsp;</td>
      <td align="center">&nbsp;</td>
      <td align="left" width="56">&nbsp;</td>
      <td align="left">Rp. 50</td>
      <td align="center"></td>
      <td align="center"></td>
      <td align="center"></td>
      <td align="center">&nbsp;</td>
      <td align="center">&nbsp;</td>
      <td align="center">.....................</td>
      <td align="center"><strong>Keping</strong></td>
      <td align="center"></td>
      <td align="right">&nbsp;</td>
      <td align="right">&nbsp;</td>
      <td align="right">&nbsp;</td>
      <td align="right">&nbsp;</td>
      <td align="right">&nbsp;</td>
      <td align="right">Rp.</td>
      <td align="right"></td>
      <td align="right"></td>
  </tr><tr>
      <td align="center">&nbsp;</td>
      <td align="center">&nbsp;</td>
      <td align="left">&nbsp;</td>
      <td align="left">&nbsp;</td>
      <td align="center"></td>
      <td align="center"></td>
      <td align="center"></td>
      <td align="center"></td>
      <td align="center"></td>
      <td align="center"></td>
      <td align="center"></td>
      <td align="center"></td>
      <td align="center"></td>
      <td align="center"></td>
      <td align="center"></td>
      <td align="center"></td>
      <td align="center"></td>
      <td align="right">&nbsp;</td>
      <td align="center"></td>
      <td align="center"></td>
  </tr><tr>
      <td align="center">&nbsp;</td>
      <td align="center">&nbsp;</td>
      <td align="left">&nbsp;</td>
      <td align="left">&nbsp;</td>
      <td align="center"></td>
      <td align="center"></td>
      <td align="center"></td>
      <td align="center">&nbsp;</td>
      <td align="center"></td>
      <td align="center"><strong>Jumlah (2)</strong></td>
      <td align="center"></td>
      <td align="center"></td>
      <td align="center"></td>
      <td align="center"></td>
      <td align="center"></td>
      <td align="center"></td>
      <td align="center"></td>
      <td align="center">Rp.</td>
      <td align="center"></td>
      <td align="center"></td>
  </tr><tr>
      <td align="center">&nbsp;</td>
      <td align="center">&nbsp;</td>
      <td align="left" width="56">&nbsp;</td>
      <td align="left">&nbsp;</td>
      <td align="center"></td>
      <td align="center"></td>
      <td align="center"></td>
      <td align="center"></td>
      <td align="center"></td>
      <td align="center"></td>
      <td align="center"></td>
      <td align="center"></td>
      <td align="center"></td>
      <td align="center"></td>
      <td align="center"></td>
      <td align="center"></td>
      <td align="center"></td>
      <td align="center"></td>
      <td align="center"></td>
      <td align="center"></td>
  </tr><tr>
      <td align="center">&nbsp;</td>
      <td align="left"><strong>3</strong></td>
      <td colspan="2" align="left"><strong>Pengeluaran yg belum di SPJ kan :</strong></td>
      <td align="center"></td>
      <td align="center"></td>
      <td align="center"></td>
      <td align="center"></td>
      <td align="center"></td>
      <td align="center"></td>
      <td align="center"></td>
      <td align="center"></td>
      <td align="center">&nbsp;</td>
      <td align="center">&nbsp;</td>
      <td align="center">&nbsp;</td>
      <td align="center">&nbsp;</td>
      <td align="center">&nbsp;</td>
      <td align="center">&nbsp;</td>
      <td align="center">&nbsp;</td>
      <td align="center">&nbsp;</td>
  </tr><tr>
      <td align="center">&nbsp;</td>
      <td align="center">&nbsp;</td>
      <td align="left">&nbsp;</td>
      <td align="left">&nbsp;</td>
      <td align="center">&nbsp;</td>
      <td align="center"></td>
      <td align="center">&nbsp;</td>
      <td align="center">&nbsp;</td>
      <td align="center">&nbsp;</td>
      <td align="center">&nbsp;</td>
      <td align="center">&nbsp;</td>
      <td align="center">&nbsp;</td>
      <td align="center">&nbsp;</td>
      <td align="center">&nbsp;</td>
      <td align="center">&nbsp;</td>
      <td align="center">&nbsp;</td>
      <td align="center">&nbsp;</td>
      <td align="center">&nbsp;</td>
      <td align="center">&nbsp;</td>
      <td align="center">&nbsp;</td>
  </tr><tr>
      <td align="center">&nbsp;</td>
      <td align="center">&nbsp;</td>
      <td align="left">&nbsp;</td>
      <td align="center"><strong>No. BS</strong></td>
      <td align="center">&nbsp;</td>
      <td align="center"><strong>Jumlah (1+2+3)</strong></td>
      <td align="center">&nbsp;</td>
      <td align="center"><strong>Atas Nama</strong></td>
      <td align="center">&nbsp;</td>
      <td align="center"><strong>Keperluan</strong></td>
      <td align="center">&nbsp;</td>
      <td align="center">&nbsp;</td>
      <td align="center">&nbsp;</td>
      <td align="center"><strong>Jumlah</strong></td>
      <td align="center">&nbsp;</td>
      <td align="center">&nbsp;</td>
      <td align="center">&nbsp;</td>
      <td align="center">&nbsp;</td>
      <td align="center">&nbsp;</td>
      <td align="center">&nbsp;</td>
  </tr><tr>
      <td align="center">&nbsp;</td>
      <td align="center">&nbsp;</td>
      <td align="left">&nbsp;</td>
      <td align="center"><strong>......</strong></td>
      <td align="center">&nbsp;</td>
      <td align="center"><strong>.....................</strong></td>
      <td align="center">&nbsp;</td>
      <td align="center"><strong>.....................</strong></td>
      <td align="center">&nbsp;</td>
      <td align="center"><strong>.....................</strong></td>
      <td align="center">&nbsp;</td>
      <td align="center">&nbsp;</td>
      <td align="center"></td>
      <td align="center"></td>
      <td align="center"></td>
      <td align="center"></td>
      <td align="center"></td>
      <td align="center">&nbsp;</td>
      <td align="center">&nbsp;</td>
      <td align="center">&nbsp;</td>
  </tr><tr>
      <td align="center">&nbsp;</td>
      <td align="center">&nbsp;</td>
      <td align="left">&nbsp;</td>
      <td align="center"><strong>......</strong></td>
      <td align="center">&nbsp;</td>
      <td align="center"><strong>.....................</strong></td>
      <td align="center">&nbsp;</td>
      <td align="center"><strong>.....................</strong></td>
      <td align="center">&nbsp;</td>
      <td align="center"><strong>.....................</strong></td>
      <td align="center">&nbsp;</td>
      <td align="center">&nbsp;</td>
      <td align="center"></td>
      <td align="center"></td>
      <td align="center"></td>
      <td align="center"></td>
      <td align="center"></td>
      <td align="center">&nbsp;</td>
      <td align="center">&nbsp;</td>
      <td align="center">&nbsp;</td>
  </tr><tr>
      <td align="center">&nbsp;</td>
      <td align="center">&nbsp;</td>
      <td align="left">&nbsp;</td>
      <td align="center"><strong>......</strong></td>
      <td align="center">&nbsp;</td>
      <td align="center"><strong>.....................</strong></td>
      <td align="center">&nbsp;</td>
      <td align="center"><strong>.....................</strong></td>
      <td align="center">&nbsp;</td>
      <td align="center"><strong>.....................</strong></td>
      <td align="center">&nbsp;</td>
      <td align="center">&nbsp;</td>
      <td align="center"></td>
      <td align="center"></td>
      <td align="center"></td>
      <td align="center"></td>
      <td align="center"></td>
      <td align="center">&nbsp;</td>
      <td align="center">&nbsp;</td>
      <td align="center">&nbsp;</td>
  </tr><tr>
      <td align="center">&nbsp;</td>
      <td align="center">&nbsp;</td>
      <td align="left">&nbsp;</td>
      <td align="center"><strong>......</strong></td>
      <td align="center">&nbsp;</td>
      <td align="center"><strong>.....................</strong></td>
      <td align="center">&nbsp;</td>
      <td align="center"><strong>.....................</strong></td>
      <td align="center">&nbsp;</td>
      <td align="center"><strong>.....................</strong></td>
      <td align="center">&nbsp;</td>
      <td align="center">&nbsp;</td>
      <td align="center"></td>
      <td align="center"></td>
      <td align="center"></td>
      <td align="center"></td>
      <td align="center"></td>
      <td align="center">&nbsp;</td>
      <td align="center">&nbsp;</td>
      <td align="center">&nbsp;</td>
  </tr><tr>
      <td align="center">&nbsp;</td>
      <td align="center">&nbsp;</td>
      <td align="left">&nbsp;</td>
      <td align="center"><strong>......</strong></td>
      <td align="center">&nbsp;</td>
      <td align="center"><strong>.....................</strong></td>
      <td align="center">&nbsp;</td>
      <td align="center"><strong>.....................</strong></td>
      <td align="center">&nbsp;</td>
      <td align="center"><strong>.....................</strong></td>
      <td align="center">&nbsp;</td>
      <td align="center">&nbsp;</td>
      <td align="center"></td>
      <td align="center"></td>
      <td align="center"></td>
      <td align="center"></td>
      <td align="center"></td>
      <td align="center">&nbsp;</td>
      <td align="center">&nbsp;</td>
      <td align="center">&nbsp;</td>
  </tr><tr>
      <td align="center">&nbsp;</td>
      <td align="center">&nbsp;</td>
      <td align="left">&nbsp;</td>
      <td align="center"><strong>......</strong></td>
      <td align="center">&nbsp;</td>
      <td align="center"><strong>.....................</strong></td>
      <td align="center">&nbsp;</td>
      <td align="center"><strong>.....................</strong></td>
      <td align="center">&nbsp;</td>
      <td align="center"><strong>.....................</strong></td>
      <td align="center">&nbsp;</td>
      <td align="center">&nbsp;</td>
      <td align="center"></td>
      <td align="center"></td>
      <td align="center"></td>
      <td align="center"></td>
      <td align="center"></td>
      <td align="center">&nbsp;</td>
      <td align="center">&nbsp;</td>
      <td align="center">&nbsp;</td>
  </tr><tr>
      <td align="center">&nbsp;</td>
      <td align="center">&nbsp;</td>
      <td align="left">&nbsp;</td>
      <td align="left">&nbsp;</td>
      <td align="center"></td>
      <td align="center"></td>
      <td align="center"></td>
      <td align="center"></td>
      <td align="right" >&nbsp;</td>
      <td align="center"><strong>Jumlah (3)</strong></td>
      <td align="center">&nbsp;</td>
      <td align="center">&nbsp;</td>
      <td align="right">&nbsp;</td>
      <td align="right">&nbsp;</td>
      <td align="right">&nbsp;</td>
      <td align="right">&nbsp;</td>
      <td align="right">&nbsp;</td>
      <td align="right">Rp.</td>
      <td align="right" style="border-bottom:#000000 solid 1px;">&nbsp;</td>
      <td align="right" style="border-bottom:#000000 solid 1px;">&nbsp;</td>
  </tr><tr>
      <td align="center">&nbsp;</td>
      <td align="center">&nbsp;</td>
      <td align="left">&nbsp;</td>
      <td align="left">&nbsp;</td>
      <td align="center"></td>
      <td align="center"></td>
      <td align="center"></td>
      <td align="center"></td>
      <td align="center"></td>
      <td align="center"></td>
      <td align="center"></td>
      <td align="center"><strong>Jumlah (1+2+3)</strong></td>
      <td align="center"></td>
      <td colspan="2" align="center">&nbsp;</td>
      <td align="center"></td>
      <td align="center"></td>
      <td align="right">Rp.</td>
      <td align="right">&nbsp;</td>
      <td align="right">&nbsp;</td>
  </tr><tr>
      <td align="center">&nbsp;</td>
      <td align="center">&nbsp;</td>
      <td align="left">&nbsp;</td>
      <td align="left">&nbsp;</td>
      <td align="center"></td>
      <td align="center"></td>
      <td align="center"></td>
      <td align="center"></td>
      <td align="right">&nbsp;</td>
      <td align="right"></td>
      <td align="center"></td>
      <td align="center"></td>
      <td align="right">&nbsp;</td>
      <td align="right">&nbsp;</td>
      <td align="right">&nbsp;</td>
      <td align="right">&nbsp;</td>
      <td align="right">&nbsp;</td>
      <td align="right">Rp.</td>
      <td align="right" style="border-bottom:#000000 solid 1px;">&nbsp;</td>
      <td align="right" style="border-bottom:#000000 solid 1px;">&nbsp;</td>
  </tr><tr>
      <td align="center">&nbsp;</td>
      <td align="left"><strong>4</strong></td>
      <td colspan="2" align="left"><strong>Plafon Kas Kecil</strong></td>
      <td align="center"></td>
      <td align="center"></td>
      <td align="center"></td>
      <td align="center"></td>
      <td align="right">&nbsp;</td>
      <td align="right"></td>
      <td align="center"></td>
      <td align="center"></td>
      <td align="right">&nbsp;</td>
      <td align="right">&nbsp;</td>
      <td align="right">&nbsp;</td>
      <td align="right">&nbsp;</td>
      <td align="right">&nbsp;</td>
      <td align="right">&nbsp;</td>
      <td align="right">&nbsp;</td>
      <td align="right">&nbsp;</td>
  </tr><tr>
      <td align="center">&nbsp;</td>
      <td align="center">&nbsp;</td>
      <td align="left">&nbsp;</td>
      <td align="left">&nbsp;</td>
      <td align="center"></td>
      <td align="center"></td>
      <td align="center"></td>
      <td align="center"></td>
      <td align="center"></td>
      <td align="center"></td>
      <td colspan="2" align="center">Perbedaan Positif/Negatif</td>
      <td align="center"></td>
      <td align="center"></td>
      <td align="center"></td>
      <td align="center"></td>
      <td align="center"></td>
      <td align="center">Rp.</td>
      <td align="center" style="border-bottom:double"></td>
      <td align="center" style="border-bottom:double"></td>
  </tr><tr>
      <td align="center">&nbsp;</td>
      <td align="center">&nbsp;</td>
      <td align="left">&nbsp;</td>
      <td align="left">&nbsp;</td>
      <td align="center"></td>
      <td align="center"></td>
      <td align="center"></td>
      <td align="center"></td>
      <td align="right">&nbsp;</td>
      <td align="right"></td>
      <td align="center"></td>
      <td align="center"></td>
      <td align="right">&nbsp;</td>
      <td align="right">&nbsp;</td>
      <td align="right">&nbsp;</td>
      <td align="right">&nbsp;</td>
      <td align="right">&nbsp;</td>
      <td align="right">&nbsp;</td>
      <td align="right">&nbsp;</td>
      <td align="right">&nbsp;</td>
  </tr><tr>
      <td colspan="3" rowspan="4" valign="top">Penjelasan :</td>
      <td colspan="12" align="left">..................................................................................................................................................................................</td>
      <td align="center"></td>
      <td align="center"></td>
      <td align="center"></td>
      <td align="center"></td>
      <td align="center"></td>
  </tr><tr>
      <td colspan="12" align="left">..................................................................................................................................................................................</td>
      <td align="center"></td>
      <td align="center"></td>
      <td align="center"></td>
      <td align="center"></td>
      <td align="center"></td>
  </tr><tr>
      <td colspan="12" align="left">..................................................................................................................................................................................</td>
      <td align="center"></td>
      <td align="center"></td>
      <td align="center"></td>
      <td align="center"></td>
      <td align="center"></td>
  </tr><tr>
      <td colspan="12" align="left">..................................................................................................................................................................................</td>
      <td align="center"></td>
      <td align="center"></td>
      <td align="center"></td>
      <td align="center"></td>
      <td align="center"></td>
  </tr><tr>
      <td align="center">&nbsp;</td>
      <td align="center">&nbsp;</td>
      <td align="left">&nbsp;</td>
      <td align="left">&nbsp;</td>
      <td align="center"></td>
      <td align="center"></td>
      <td align="center"></td>
      <td align="center"></td>
      <td align="center"></td>
      <td align="center"></td>
      <td align="center"></td>
      <td align="center"></td>
      <td align="center"></td>
      <td align="center"></td>
      <td align="center"></td>
      <td align="center"></td>
      <td align="center"></td>
      <td align="center"></td>
      <td align="center"></td>
      <td align="center"></td>
  </tr><tr>
      <td colspan="2" align="center">...........,</td>
      <td colspan="2" align="left">Tgl, .....................</td>
      <td align="center"></td>
      <td align="center"></td>
      <td align="center"></td>
      <td align="center"></td>
      <td align="center"></td>
      <td align="center"></td>
      <td align="center"></td>
      <td align="center"></td>
      <td align="center"></td>
      <td align="center"></td>
      <td align="center"></td>
      <td align="center"></td>
      <td align="center"></td>
      <td align="center"></td>
      <td align="center"></td>
      <td align="center"></td>
  </tr><tr>
      <td align="center">&nbsp;</td>
      <td align="center">&nbsp;</td>
      <td align="left">&nbsp;</td>
      <td align="left">&nbsp;</td>
      <td align="center"></td>
      <td align="center"></td>
      <td align="center"></td>
      <td align="center"></td>
      <td align="center"></td>
      <td align="center"></td>
      <td align="center"></td>
      <td align="center"></td>
      <td align="center"></td>
      <td align="center"></td>
      <td align="center"></td>
      <td align="center"></td>
      <td align="center"></td>
      <td align="center"></td>
      <td align="center"></td>
      <td align="center"></td>
  </tr><tr>
      <td align="center">&nbsp;</td>
      <td align="center">&nbsp;</td>
      <td align="left">&nbsp;</td>
      <td align="center">Mengetahui,</td>
      <td align="center"></td>
      <td align="center"></td>
      <td align="center"></td>
      <td align="center"></td>
      <td align="center"></td>
      <td align="center">Petugas Kas Opname</td>
      <td align="center"></td>
      <td align="center">Pemegang Kas Kecil</td>
      <td align="center"></td>
      <td align="center"></td>
      <td align="center"></td>
      <td align="center"></td>
      <td align="center"></td>
      <td align="center"></td>
      <td align="center"></td>
      <td align="center"></td>
  </tr><tr>
      <td align="center">&nbsp;</td>
      <td align="center">&nbsp;</td>
      <td align="left">&nbsp;</td>
      <td align="left">&nbsp;</td>
      <td align="center"></td>
      <td align="center"></td>
      <td align="center"></td>
      <td align="center"></td>
      <td align="center"></td>
      <td align="center"></td>
      <td align="center"></td>
      <td align="center"></td>
      <td align="center"></td>
      <td align="center"></td>
      <td align="center"></td>
      <td align="center"></td>
      <td align="center"></td>
      <td align="center"></td>
      <td align="center"></td>
      <td align="center"></td>
  </tr><tr>
      <td align="center">&nbsp;</td>
      <td align="center">&nbsp;</td>
      <td align="left">&nbsp;</td>
      <td align="left">&nbsp;</td>
      <td align="center"></td>
      <td align="center"></td>
      <td align="center"></td>
      <td align="center"></td>
      <td align="center"></td>
      <td align="center"></td>
      <td align="center"></td>
      <td align="center"></td>
      <td align="center"></td>
      <td align="center"></td>
      <td align="center"></td>
      <td align="center"></td>
      <td align="center"></td>
      <td align="center"></td>
      <td align="center"></td>
      <td align="center"></td>
  </tr><tr>
      <td align="center">&nbsp;</td>
      <td align="center">&nbsp;</td>
      <td align="left">&nbsp;</td>
      <td align="left">&nbsp;</td>
      <td align="center"></td>
      <td align="center"></td>
      <td align="center"></td>
      <td align="center"></td>
      <td align="center"></td>
      <td align="center"></td>
      <td align="center"></td>
      <td align="center"></td>
      <td align="center"></td>
      <td align="center"></td>
      <td align="center"></td>
      <td align="center"></td>
      <td align="center"></td>
      <td align="center"></td>
      <td align="center"></td>
      <td align="center"></td>
  </tr><tr>
      <td align="center">&nbsp;</td>
      <td colspan="2" align="center">.........................</td>
      <td align="left">&nbsp;</td>
      <td align="center">&nbsp;</td>
      <td align="center">.........................</td>
      <td align="center">&nbsp;</td>
      <td align="center">&nbsp;</td>
      <td align="center">&nbsp;</td>
      <td align="center">.........................</td>
      <td align="center">&nbsp;</td>
      <td align="center">.........................</td>
      <td align="center">&nbsp;</td>
      <td align="center">&nbsp;</td>
      <td align="center">&nbsp;</td>
      <td align="center">&nbsp;</td>
      <td align="center">&nbsp;</td>
      <td align="center">&nbsp;</td>
      <td align="center">&nbsp;</td>
      <td align="center">&nbsp;</td>
  </tr><tr>
      <td align="center">&nbsp;</td>
      <td colspan="2" align="center">Kabag Keuangan</td>
      <td align="left">&nbsp;</td>
      <td align="center">&nbsp;</td>
      <td align="center">Bendahara Pengeluaran</td>
      <td align="center">&nbsp;</td>
      <td align="center">&nbsp;</td>
      <td align="right">&nbsp;</td>
      <td align="right">&nbsp;</td>
      <td align="center">&nbsp;</td>
      <td align="center">&nbsp;</td>
      <td align="right">&nbsp;</td>
      <td align="right">&nbsp;</td>
      <td align="right">&nbsp;</td>
      <td align="right">&nbsp;</td>
      <td align="right">&nbsp;</td>
      <td align="right">&nbsp;</td>
      <td align="right">&nbsp;</td>
      <td align="right">&nbsp;</td>
   </tr>
</table>
</form>
</body>
</html>