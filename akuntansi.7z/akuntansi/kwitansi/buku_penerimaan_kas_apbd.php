<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>.: BUKU PENERIMAAN KAS APBD :.</title>
</head>

<body>
<form>
 <table width="500" border="0" cellspacing="0" cellpadding="0" style="font-family:Arial, Helvetica, sans-serif; font-size:12px;">
  <tr>
    <td><b>RSUD KOTA TANGERANG<br />
      Jl. Jendral Sudirman No.101 Tangerang
       <br/></b></td>
  </tr><tr>
      <td align="center" height="50" style="font-size:14px; text-transform:uppercase">Buku Penerimaan Kas APBD</td>
  </tr><tr>
      <td align="center" style="font-size:14px; text-transform:uppercase">bulan.......</td>
  </tr><tr>
      <td>Nama Bank :</td>
  </tr><tr>
      <td>No Rekening :</td>
  </tr><tr>
      <td align="right" valign="top" style="font-family: Arial; font-size: 12px; text-align: center;"><table width="100%" border="1" cellpadding="0" cellspacing="0" style="border-collapse:collapse">
  <tr>
      <td height="30" colspan="2" style="border-bottom:#000000 solid 1px; border-top:#000000 1px solid; font-weight:bold; text-align:center;">Bukti Kas Masuk</td>
      <td width="4%" style="border-bottom:#000000 solid 1px; border-top:#000000 1px solid; font-weight:bold; text-align:center;">Uraian</td>
      <td colspan="4" style="border-bottom:#000000 solid 1px; border-top:#000000 1px solid; font-weight:bold; text-align:center;">Pendapatan BLUD</td>
      <td width="4%" rowspan="2" style="border-bottom:#000000 solid 1px; border-top:#000000 1px solid; font-weight:bold; text-align:center;">Jumlah</td>
  </tr><tr>
      <td width="2%" style="text-align:center;">Nomor</td>
      <td width="2%" style="text-align:center;">Tanggal</td>
      <td>&nbsp;</td>
      <td width="2%" style="text-align:center;">Pegawai</td>
      <td width="2%" style="text-align:center;">Barjas</td>
      <td width="2%" style="text-align:center;">Modal</td>
      <td width="2%" style="text-align:center;">Lain-lain</td>
  </tr><tr>
      <td style="text-align:center;">BKM....</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
  </tr><tr>
      <td style="text-align:center;">&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
  </tr><tr>
      <td style="text-align:center;">&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
  </tr><tr>
      <td style="text-align:center;">&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
  </tr><tr>
      <td style="text-align:center;">&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
  </tr><tr>
      <td style="text-align:center;">&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
  </tr><tr>
      <td style="text-align:center;">&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
  </tr><tr>
      <td style="text-align:center;">&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
  </tr><tr>
      <td style="text-align:center;">&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
  </tr><tr>
      <td style="text-align:center;">&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
  </tr><tr>
      <td style="text-align:center;">&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
  </tr><tr>
      <td style="text-align:center;">&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
  </tr><tr>
      <td style="text-align:center;">&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
  </tr><tr>
      <td style="text-align:center;">&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
  </tr><tr>
      <td style="text-align:center;">&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
  </tr><tr>
      <td style="text-align:center;">&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
  </tr><tr>
      <td style="text-align:center;">&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
  </tr><tr>
      <td style="text-align:center;">&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
  </tr><tr>
      <td style="text-align:center;">&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
  </tr><tr>
      <td style="text-align:center;">&nbsp;</td>
      <td align="right">&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
  </tr><tr>
      <td style="text-align:center;">&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
  </tr><tr>
      <td style="text-align:center;">&nbsp;</td>
      <td>&nbsp;</td>
      <td align="right">&nbsp;</td>
      <td align="right">&nbsp;</td>
      <td align="right">&nbsp;</td>
      <td align="right">&nbsp;</td>
      <td align="right">&nbsp;</td>
      <td align="right">&nbsp;</td>
  </tr><tr>
      <td colspan="3" bgcolor="#CCCCCC" style="text-align:center;">Jumlah</td>
      <td align="right" bgcolor="#CCCCCC">&nbsp;</td>
      <td align="right" bgcolor="#CCCCCC">&nbsp;</td>
      <td align="right" bgcolor="#CCCCCC">&nbsp;</td>
      <td align="right" bgcolor="#CCCCCC">&nbsp;</td>
      <td align="right" bgcolor="#CCCCCC">&nbsp;</td>
  </tr><tr>
      <td colspan="3" style="text-align:center;">(-) Penerimaan Bulan Sebelumnya Disetor Bulan Ini</td>
      <td align="right">&nbsp;</td>
      <td align="right">&nbsp;</td>
      <td align="right">&nbsp;</td>
      <td align="right">&nbsp;</td>
      <td align="right">&nbsp;</td>
  </tr><tr>
      <td colspan="3" style="text-align:center;">(+) Penerimaan Bulan Ini Belum Disetor</td>
      <td align="right">&nbsp;</td>
      <td align="right">&nbsp;</td>
      <td align="right">&nbsp;</td>
      <td align="right">&nbsp;</td>
      <td align="right">&nbsp;</td>
  </tr><tr>
      <td colspan="3" bgcolor="#CCCCCC" style="text-align:center;">Jumlah Penerimaan Kas Bulan Ini</td>
      <td align="right" bgcolor="#CCCCCC">&nbsp;</td>
      <td align="right" bgcolor="#CCCCCC">&nbsp;</td>
      <td align="right" bgcolor="#CCCCCC">&nbsp;</td>
      <td align="right" bgcolor="#CCCCCC">&nbsp;</td>
      <td align="right" bgcolor="#CCCCCC">&nbsp;</td>
  </tr>
</table>
<table width="1164">
  <tr height="30">
      <td width="306">Catatan : Menggunakan Basis Kas</td>
      <td width="422"></td>
      <td width="40"></td>
      <td width="376">.....................,......................</td>
  </tr>
</table>
<table width="1390">
  <tr>
      <td width="95">&nbsp;</td>
      <td width="95">&nbsp;</td>
      <td width="356">Mengetahui</td>
      <td width="824">Bendahara Penerimaan</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>Pemimpin BLUD</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td><br />
...............................</td>
      <td><p>...............................</p></td>
  </tr>
</table>
</form>
</body>
</html>