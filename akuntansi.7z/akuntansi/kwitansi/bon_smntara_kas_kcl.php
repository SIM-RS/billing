<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>.:BON SEMENTARA KAS KECIL:.</title>
</head>

<body>
<form>
 <table width="1048">
    <tr>
      <td width="806"><strong>RSUD KOTA TANGERANG</strong></td>
      <td width="45">Nomor</td>
      <td width="11">:</td>
      <td width="166">BSK...</td>
    </tr><tr>
      <td width="806"><strong>Jl. Jendral Sudirman No. 101 Tangerang</strong></td>
      <td width="45">Tanggal</td>
      <td width="11">:</td>
      <td>&nbsp;</td>
    </tr><tr>
      <td height="50" colspan="3" align="center" style="font-size:18px;"><strong>BON SEMENTARA KAS KECIL</strong></td>
    </tr>
 </table>
 <table width="561">
    <tr>
      <td width="110">Uang Sejumlah</td>
      <td width="13">:</td>
      <td width="422">Rp.</td>
  </tr><tr>
      <td width="110">Terbilang</td>
      <td width="13">:</td>
      <td width="422">..............................................................................................</td>
  </tr><tr>
      <td width="110">Keperluan</td>
      <td width="13">:</td>
      <td width="422">..............................................................................................</td>
  </tr><tr>
      <td height="50" colspan="3" align="center" style="font-size:15px;"><p>Penerima</p>
      <p>&nbsp;</p>
      <p>..........................</p>
      <p>&nbsp;</p></td>
  </tr>
</table>
<table border="0" cellpadding="0" cellspacing="0">
  <tr>
      <td width="60">Bukti</td>
      <td colspan="2">Terlampir Tidak Ada</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
  </tr><tr>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td style="border-bottom:1px solid; border-bottom:1px solid #000000;"></td>
      <td style="border-bottom:1px solid; border-bottom:1px solid #000000;"></td>
      <td style="border-bottom:1px solid; border-bottom:1px solid #000000;"></td>
      <td style="border-bottom:1px solid; border-bottom:1px solid #000000;"></td>
      <td width="4" style="border-bottom:1px solid; border-bottom:1px solid #000000;"></td>
  </tr><tr>
      <td>&nbsp;</td>
      <td width="223">&nbsp;</td>
      <td width="42">&nbsp;</td>
      <td width="189" bgcolor="#999999" style="border-bottom:1px solid; text-align:center; border-bottom:1px solid #000000; border-left:1px solid #000000;">Menyetujui</td>
      <td width="178" bgcolor="#999999" style="border-bottom:1px solid; text-align:center; border-bottom:1px solid #000000; border-left:1px solid #000000;">Diserahkan</td>
      <td width="184" bgcolor="#999999" style="border-bottom:1px solid; text-align:center; border-bottom:1px solid #000000; border-left:1px solid #000000;">Mengetahui</td>
      <td width="176" bgcolor="#999999" style="border-bottom:1px solid; text-align:center; border-bottom:1px solid #000000; border-right:1px solid #000000; border-left:1px solid #000000;">Diajukan</td>
  </tr><tr>
      <td><u>Catatan*</u></td>
      <td>Bon Sementara Kas Kecil</td>
      <td>&nbsp;</td>
      <td style="border-left:1px solid #000000;"></td>
      <td style="border-left:1px solid #000000;"></td>
      <td style="border-left:1px solid #000000;"></td>
      <td style="border-right:1px solid #000000; border-left:1px solid #000000;"></td>
  </tr><tr>
      <td>&nbsp;</td>
      <td>Paling lambat harus dipertanggung</td>
      <td></td>
      <td style="border-left:1px solid #000000;"></td>
      <td style="border-left:1px solid #000000;"></td>
      <td style="border-left:1px solid #000000;"></td>
      <td style="border-right:1px solid #000000; border-left:1px solid #000000;"></td>
  </tr><tr>
      <td>&nbsp;</td>
      <td>jawabkan tanggal : ......................</td>
      <td></td>
      <td style="border-left:1px solid #000000;"></td>
      <td style="border-left:1px solid #000000;"></td>
      <td style="border-left:1px solid #000000;"></td>
      <td style="border-right:1px solid #000000; border-left:1px solid #000000;"></td>
  </tr><tr>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td style="border-bottom:1px solid; text-align:center; border-bottom:1px solid #000000; border-left:1px solid #000000;">Bdh. Pengeluaran</td>
      <td style="border-bottom:1px solid; text-align:center; border-bottom:1px solid #000000; border-left:1px solid #000000;">Pemegang Kas Kecil</td>
      <td style="border-bottom:1px solid; text-align:center; border-bottom:1px solid #000000; border-left:1px solid #000000;">Atasan Yang Membutuhkan</td>
      <td style="border-bottom:1px solid; text-align:center; border-bottom:1px solid #000000; border-right:1px solid #000000; border-left:1px solid #000000;">Yang Membutuhkan</td>
  </tr><tr>
      <td colspan="2">*)Diisi oleh Pemegang Kas Kecil</td>
  </tr>  
 </table>
</form>
</body>
</html>