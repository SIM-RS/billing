<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN""http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>.:LAPORAN PENDAPATAN BLUD:.</title>
</head>

<body>
<form>
  <table width="100%">
    <tr>
      <td width="1030" style="font-weight:bold;">RSUD KOTA TANGERANG</td>
    </tr><tr>
      <td width="1030" style="font-weight:bold;">Jl. Jendral Sudirman No. 101 Tangerang</td>
    </tr><tr>
      <td height="30" colspan="3" align="center" style="font-size:16px;">LAPORAN PENDAPATAN BLUD</td>
    </tr><tr>  
      <td colspan="3" align="center" style="font-size:16px;">TRIWULAN........TAHUN........</td>
    </tr>
  </table>
  <table width="100%" border="1" cellpadding="0" cellspacing="0" style="border-collapse:collapse">
     <tr>
        <td width="39" style="border-bottom:#000000 solid 1px; border-top:#000000 1px solid; font-weight:bold; text-align:center;">No</td>
        <td width="162" style="border-bottom:#000000 solid 1px; border-top:#000000 1px solid; font-weight:bold; text-align:center;">Uraian</td>
        <td width="138" style="border-bottom:#000000 solid 1px; border-top:#000000 1px solid; font-weight:bold; text-align:center;">Anggaran Dalam DPA</td>
        <td width="172" style="border-bottom:#000000 solid 1px; border-top:#000000 1px solid; font-weight:bold; text-align:center;">Realisasi s/d Triwulan Lalu</td>
        <td width="151" style="border-bottom:#000000 solid 1px; border-top:#000000 1px solid; font-weight:bold; text-align:center;">Realisasi s/d Triwulan Ini</td>
        <td width="172" style="border-bottom:#000000 solid 1px; border-top:#000000 1px solid; font-weight:bold; text-align:center;">Realisasi s/d Triwulan ini</td>
        <td width="113" style="border-bottom:#000000 solid 1px; border-top:#000000 1px solid; font-weight:bold; text-align:center;">Lebih (Kurang)</td>
	</tr><tr>
        <td align="center" width="39">(1)</td>
        <td align="center" width="162">(2)</td>
        <td align="center" width="138">(3)</td>
        <td align="center" width="172">(4)</td>
        <td align="center" width="151">(5)</td>
        <td align="center" width="172">(6)=(4)+(5)</td>
        <td align="center" width="113">(7)=(3)-(6)</td>
    </tr><tr>
        <td align="center" width="39">1</td>
        <td align="left" width="162">Pendapatan Jasa Layanan</td>
        <td align="center" width="138"></td>
        <td align="center" width="172"></td>
        <td align="center" width="151"></td>
        <td align="center" width="172"></td>
        <td align="center" width="113"></td>
    </tr><tr>
        <td align="center" width="39">2</td>
        <td align="left" width="162">Pendapatan Hibah</td>
        <td align="center" width="138"></td>
        <td align="center" width="172"></td>
        <td align="center" width="151"></td>
        <td align="center" width="172"></td>
        <td align="center" width="113"></td>
    </tr><tr>
        <td align="center" width="39">3</td>
        <td align="left" width="162">Pendapatan Kerjasama</td>
        <td align="center" width="138"></td>
        <td align="center" width="172"></td>
        <td align="center" width="151"></td>
        <td align="center" width="172"></td>
        <td align="center" width="113"></td>
    </tr><tr>
        <td align="center" width="39">2</td>
        <td align="left" width="162">Pendapatan Lain-lain</td>
        <td align="center" width="138"></td>
        <td align="center" width="172"></td>
        <td align="center" width="151"></td>
        <td align="center" width="172"></td>
        <td align="center" width="113"></td>
    </tr><tr>
        <td align="center" width="39"></td>
        <td align="center" width="162">Jumlah</td>
        <td align="center" width="138"></td>
        <td align="center" width="172"></td>
        <td align="center" width="151"></td>
        <td align="center" width="172"></td>
        <td align="center" width="113"></td>
    </tr>
  </table>
  <table width="100%">
    <tr>
        <td width="47"></td>
        <td width="245"></td>
        <td width="282"></td>
        <td width="274"></td>
        <td width="10"></td>
        <td width="11"></td>
        <td width="11"></td>
        <td width="11"></td>
        <td width="14"></td>
        <td width="14"></td>
    </tr><tr>
        <td>Catatan</td>
        <td>: Menggunakan Basis Kas</td>
        <td>&nbsp;</td>
        <td>....................................,....................</td>
    </tr><tr>
        <td></td>
        <td>Khusus Melaporkan Dana BLUD</td>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
    </tr><tr>
        <td></td>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
    </tr><tr>
        <td>&nbsp;</td>
        <td>Mengetahui</td>
        <td>&nbsp;</td>
        <td>Pemimpin BLUD</td>
    </tr><tr>
        <td>&nbsp;</td>
        <td>Kepala Dinas Pendapatan,</td>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
    </tr><tr>
        <td>&nbsp;</td>
        <td>Pengelolaan Keuangan dan Aset</td>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
    </tr><tr>
        <td>&nbsp;</td>
        <td>.....................................................</td>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
    </tr><tr>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
    </tr><tr>
        <td>&nbsp;</td>
        <td>.....................................................</td>
        <td>.....................................................</td>
        <td>.....................................................</td>
    </tr>  
  </table>
</form>
</body>
</html>