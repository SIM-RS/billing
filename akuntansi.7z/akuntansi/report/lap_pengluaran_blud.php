<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN""http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>.:LAPORAN PENGELUARAN BLUD:.</title>
</head>
<body>
<form>
  <table width="100%">
    <tr>
      <td width="1030" style="font-weight:bold;">RSUD KOTA TANGERANG</td>
    </tr>
    <tr>
      <td width="1030" style="font-weight:bold;">Jl. Jendral Sudirman No. 101 Tangerang</td>
    </tr>
    <tr>
      <td height="30" colspan="3" align="center" style="font-size:18px;">LAPORAN PENGELUARAN BLUD</td>
    </tr><tr>
      <td colspan="3" align="center" style="font-size:18px;">TRIWULAN........TAHUN........</td>
      </tr>
  </table>
  <table width="100%" border="1" cellpadding="0" cellspacing="0" style="border-collapse:collapse">
     <tr>
     	<td width="39" align="center">No</td>
     	<td width="162" align="center">Uraian</td>
     	<td width="138" align="center">Anggaran Dalam DPA</td>
     	<td width="172" align="center">Realisasi s/d Triwulan Lalu</td>
     	<td width="151" align="center">Realisasi s/d Triwulan Ini</td>
     	<td width="172" align="center">Realisasi s/d</td>
     	<td width="113" align="center">Lebih (Kurang)</td>
     </tr><tr>
        <td align="center" width="39">(1)</td>
        <td align="center" width="162">(2)</td>
        <td align="center" width="138">(3)</td>
        <td align="center" width="172">(4)</td>
        <td align="center" width="151">(5)</td>
        <td align="center" width="172">(6)=(4)+(5)</td>
        <td align="center" width="113">(7)=(3)-(6)</td>
     </tr><tr>
        <td align="center" width="39">1</td>
        <td align="left" width="162">Biaya Operasional</td>
        <td align="center" width="138"></td>
        <td align="center" width="172"></td>
        <td align="center" width="151"></td>
        <td align="center" width="172"></td>
        <td align="center" width="113"></td>
     </tr><tr>
        <td align="center" width="39">a</td>
        <td align="left" width="162">Biaya Pegawai</td>
        <td align="center" width="138"></td>
        <td align="center" width="172"></td>
        <td align="center" width="151"></td>
        <td align="center" width="172"></td>
        <td align="center" width="113"></td>
     </tr><tr>
        <td align="center">b</td>
        <td align="left">Biaya Bahan</td>
        <td align="center"></td>
        <td align="center"></td>
        <td align="center"></td>
        <td align="center"></td>
        <td align="center"></td>
     </tr><tr>
        <td align="center">c</td>
        <td align="left">Biaya Jasa Pelayanan</td>
        <td align="center"></td>
        <td align="center"></td>
        <td align="center"></td>
        <td align="center"></td>
        <td align="center"></td>
     </tr><tr>
        <td align="center">d</td>
        <td align="left">Biaya Pemeliharaan</td>
        <td align="center"></td>
        <td align="center"></td>
        <td align="center"></td>
        <td align="center"></td>
        <td align="center"></td>
     </tr><tr>
        <td align="center">e</td>
        <td align="left">Biaya Barang dan Jasa</td>
        <td align="center"></td>
        <td align="center"></td>
        <td align="center"></td>
        <td align="center"></td>
        <td align="center"></td>
     </tr><tr>
        <td align="center">f</td>
        <td align="left">Biaya Administrasi Kantor</td>
        <td align="center"></td>
        <td align="center"></td>
        <td align="center"></td>
        <td align="center"></td>
        <td align="center"></td>
     </tr><tr>
        <td align="center" width="39">g</td>
        <td align="left" width="162">Biaya Promosi</td>
        <td align="center" width="138"></td>
        <td align="center" width="172"></td>
        <td align="center" width="151"></td>
        <td align="center" width="172"></td>
        <td align="center" width="113"></td>
     </tr><tr>
        <td align="center" width="39" style="border-bottom:#000000 solid 1px;">h</td>
        <td align="left" width="162" style="border-bottom:#000000 solid 1px;">Biaya Operasional Lain</td>
        <td align="center" width="138" style="border-bottom:#000000 solid 1px;"></td>
        <td align="center" width="172" style="border-bottom:#000000 solid 1px;"></td>
        <td align="center" width="151" style="border-bottom:#000000 solid 1px;"></td>
        <td align="center" width="172" style="border-bottom:#000000 solid 1px;"></td>
        <td align="center" width="113" style="border-bottom:#000000 solid 1px;"></td>
     </tr><tr>
        <td align="center"></td>
        <td align="center">Jumlah</td>
        <td align="center"></td>
        <td align="center"></td>
        <td align="center"></td>
        <td align="center"></td>
        <td align="center"></td>
     </tr><tr>
        <td align="center"></td>
        <td align="center">&nbsp;</td>
        <td align="center"></td>
        <td align="center"></td>
        <td align="center"></td>
        <td align="center"></td>
        <td align="center"></td>
     </tr><tr>
        <td align="center">2</td>
        <td>Biaya Non Operasional</td>
        <td align="center"></td>
        <td align="center"></td>
        <td align="center"></td>
        <td align="center"></td>
        <td align="center"></td>
     </tr><tr>
        <td align="center">a</td>
        <td>Biaya PPh Jasa Giro</td>
        <td align="center"></td>
        <td align="center"></td>
        <td align="center"></td>
        <td align="center"></td>
        <td align="center"></td>
     </tr><tr>
        <td align="center">b</td>
        <td>Biaya Administrasi Bank</td>
        <td align="center"></td>
        <td align="center"></td>
        <td align="center"></td>
        <td align="center"></td>
        <td align="center"></td>
     </tr><tr>
        <td align="center" style="border-bottom:#000000 solid 1px;">c</td>
        <td style="border-bottom:#000000 solid 1px;">Biaya Non Operasional Lain</td>
        <td align="center" style="border-bottom:#000000 solid 1px;"></td>
        <td align="center" style="border-bottom:#000000 solid 1px;"></td>
        <td align="center" style="border-bottom:#000000 solid 1px;"></td>
        <td align="center" style="border-bottom:#000000 solid 1px;"></td>
        <td align="center" style="border-bottom:#000000 solid 1px;"></td>
     </tr><tr>
        <td align="center"></td>
        <td align="center">Jumlah</td>
        <td align="center"></td>
        <td align="center"></td>
        <td align="center"></td>
        <td align="center"></td>
        <td align="center"></td>
     </tr><tr>
        <td align="center"></td>
        <td align="center">&nbsp;</td>
        <td align="center"></td>
        <td align="center"></td>
        <td align="center"></td>
        <td align="center"></td>
        <td align="center"></td>
     </tr><tr>
        <td align="center">3</td>
        <td>Belanja Modal</td>
        <td align="center"></td>
        <td align="center"></td>
        <td align="center"></td>
        <td align="center"></td>
        <td align="center"></td>
     </tr><tr>
        <td align="center">a</td>
        <td>Tanah</td>
        <td align="center"></td>
        <td align="center"></td>
        <td align="center"></td>
        <td align="center"></td>
        <td align="center"></td>
     </tr><tr>
        <td align="center">b</td>
        <td>Gedung dan Bangunan</td>
        <td align="center"></td>
        <td align="center"></td>
        <td align="center"></td>
        <td align="center"></td>
        <td align="center"></td>
     </tr><tr>
        <td align="center">c</td>
        <td>Peralatan dan Mesin</td>
        <td align="center"></td>
        <td align="center"></td>
        <td align="center"></td>
        <td align="center"></td>
        <td align="center"></td>
     </tr><tr>
        <td align="center">d</td>
        <td>Jalan, Jaringan dan Instalasi</td>
        <td align="center"></td>
        <td align="center"></td>
        <td align="center"></td>
        <td align="center"></td>
        <td align="center"></td>
    </tr><tr>
        <td align="center">e</td>
        <td>Konstruksi Dalam Pelaksanaan</td>
        <td align="center"></td>
        <td align="center"></td>
        <td align="center"></td>
        <td align="center"></td>
        <td align="center"></td>
    </tr><tr>
        <td align="center" style="border-bottom:#000000 solid 1px;">f</td>
        <td style="border-bottom:#000000 solid 1px;">Aset Tetap Lainnya</td>
        <td align="center" style="border-bottom:#000000 solid 1px;"></td>
        <td align="center" style="border-bottom:#000000 solid 1px;"></td>
        <td align="center" style="border-bottom:#000000 solid 1px;"></td>
        <td align="center" style="border-bottom:#000000 solid 1px;"></td>
        <td align="center" style="border-bottom:#000000 solid 1px;"></td>
    </tr><tr>
        <td align="center"></td>
        <td align="center">Jumlah</td>
        <td align="center"></td>
        <td align="center"></td>
        <td align="center"></td>
        <td align="center"></td>
        <td align="center"></td>
    </tr><tr>
      	<td align="center" width="39" style="border-bottom:double"></td>
        <td align="center" width="162" style="border-bottom:double">Jumlah Biaya/Belanja</td>
        <td align="center" width="138" style="border-bottom:double"></td>
        <td align="center" width="172" style="border-bottom:double"></td>
        <td align="center" width="151" style="border-bottom:double"></td>
        <td align="center" width="172" style="border-bottom:double"></td>
        <td align="center" width="113" style="border-bottom:double"></td>
    </tr>
  </table>
  <table width="100%">
   	  <tr>
        <td width="47"></td>
        <td width="245"></td>
        <td width="282"></td>
        <td width="274"></td>
        <td width="10"></td>
        <td width="11"></td>
        <td width="11"></td>
        <td width="11"></td>
        <td width="14"></td>
        <td width="14"></td>
    </tr><tr>
        <td>Catatan</td>
        <td>: Menggunakan Basis Kas</td>
        <td>&nbsp;</td>
        <td>................................,....................</td>
	</tr><tr>
        <td></td>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
	</tr><tr>
        <td></td>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
	</tr><tr>
        <td>&nbsp;</td>
        <td>Mengetahui</td>
        <td>&nbsp;</td>
        <td>Pemimpin BLUD</td>
	</tr><tr>
        <td>&nbsp;</td>
        <td>Kepala Dinas Pendapatan,</td>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
	</tr><tr>
        <td>&nbsp;</td>
        <td>Pengelolaan Keuangan dan Aset</td>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
	</tr><tr>
        <td>&nbsp;</td>
        <td>Kota Balikpapan</td>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
	</tr><tr>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
	</tr><tr>
        <td>&nbsp;</td>
        <td>.....................................................</td>
        <td>&nbsp;</td>
        <td>.....................................................</td>
	</tr>  
  </table>
</form>
</body>
</html>