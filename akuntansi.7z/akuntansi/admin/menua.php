<table cellpadding="0" cellspacing="0" width="160" id="navigation">
	<tr>
		<td>&nbsp;</td>
	</tr>
	<!--tr>
		<td><a href="?f=proyek" class="navText">1.1 Buat Proyek</a></td>
	</tr-->
	<tr>
    <td><a href="?f=../master/tree_ms_ma" class="navText">Master MA</a></td>
	</tr>
	<tr>
    <td><a href="?f=../master/tree_ms_renstra" class="navText">Master Renstra</a></td>
	</tr>
	<tr>
    <td><a href="?f=../master/tree_ms_kegiatan" class="navText">Master Kegiatan</a></td>
	</tr>
</table>