<?php 
session_start();
include("../koneksi/konek.php");

$username = $_SESSION['akun_username'];
$password = $_SESSION['akun_password'];
$idunit = $_SESSION['akun_ses_idunit'];
$iduser = $_SESSION['akun_iduser'];
$kategori = $_SESSION['akun_kategori'];

$hdrFrm="Transaksi Pembelian Obat";
$tipe = $_REQUEST["tipe"];
if ($tipe==2) $hdrFrm="Transaksi Penerimaan Hibah Obat";

if (empty ($username) AND empty ($password)){
	header("Location: ../index.php");
	exit();
}

$tgl=gmdate('d-m-Y',mktime(date('H')+7));
$kso=$_REQUEST['kso'];
$tempat=$_REQUEST['tempat'];
if($_REQUEST['tglAwal']=="" || $_REQUEST['tglAkhir']==""){
	$tglAwal = $tgl;
	$tglAkhir = $tgl;
}else{
	$tglAwal = $_REQUEST['tglAwal'];
	$tglAkhir = $_REQUEST['tglAkhir'];
}
$tang = explode('-',$tanggal);
$tanggalan = $tang[2].'-'.$tang[1].'-'.$tang[0];
?>
<html>
<head>
<title>Sistem Informasi Akuntansi</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<script language="JavaScript" src="../theme/js/mod.js"></script>
<script type="text/JavaScript" language="JavaScript" src="../theme/js/dsgrid.js"></script>
<!--script src="../theme/js/noklik.js" type="text/javascript"></script-->
<link rel="stylesheet" href="../theme/simkeu.css" type="text/css" />
</head>
<body>
<div align="center">
<?php
$wktnow=gmdate('H:i:s',mktime(date('H')+7));
$wkttgl=gmdate('d/m/Y',mktime(date('H')+7));
$url=split("/",$_SERVER['REQUEST_URI']);
$imgpath="/".$url[1]."/images";
$iunit=$_SESSION['akun_username'];
?>
<style type="text/css">
<!--
.style1 {font-family: Verdana, Arial, Helvetica, sans-serif}
-->
</style>
<script>
	var arrRange=depRange=[];
</script>
<iframe height="193" width="168" name="gToday:normal:agenda.js"
	id="gToday:normal:agenda.js"
	src="../theme/popcjs.php" scrolling="no"
	frameborder="0"
	style="border:1px solid medium ridge; position: absolute; z-index: 65535; left: 100px; top: 500px; visibility: hidden">
</iframe>

<iframe height="72" width="130" name="sort"
	id="sort"
	src="../theme/dsgrid_sort.php" scrolling="no"
	frameborder="1"
	style="border:1px solid medium ridge; position: absolute; z-index: 65535; left: 100px; top: 500px; visibility: hidden">
</iframe>

<table width="1000" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td colspan="4"><img src="../images/kop3.gif" width="1000" height="100" border="0" /></td>
  </tr>
  <tr class="H">
  	<td id="dateformat" height="25">&nbsp;&nbsp;<?php echo $wkttgl; ?>&nbsp;&nbsp;login &nbsp;&nbsp;&nbsp;&nbsp;: <?=strtoupper($username); ?></td>
	<td colspan="3" id="logout" height="25" align="right">&nbsp;&nbsp;</td>
  </tr>
</table>

<script>
document.getElementById("logout").innerHTML='<a class="a1" href="http://<?php echo $_SERVER['HTTP_HOST']?>/simrs-pelindo/portal.php">Portal</a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;';
</script>
<table width="1000" border="0" cellspacing="0" cellpadding="0" class="tblbody">
	<tr align="center" valign="top">
		<td class="bodykiri"><?php include("menua.php");?></td>
	</tr>
<tr align="center" valign="top">
	<td align="left" height="430">
        <div align="center">
            <table width="980" border="0" cellpadding="0" cellspacing="0" class="txtinput">
                <tr>
                    <td class="jdltable" height="29" colspan="2"><?php echo $hdrFrm; ?></td>
                </tr>
                <tr>
                    <td style="padding-right:20px; text-align:right;" height="25" width="35%">Tanggal</td>
                    <td width="65%" style="font-weight:bold;">:&nbsp;<input id="tglAwal" name="tglAwal" readonly size="11" class="txtcenter" type="text" value="<?php echo $tglAwal; ?>" />&nbsp;<input type="button" name="btnTgl" value="&nbsp;V&nbsp;" class="tblBtn" onClick="gfPop.fPopCalendar(document.getElementById('tglAwal'),depRange);"/> s.d. <input id="tglAkhir" name="tglAkhir" readonly size="11" class="txtcenter" type="text" value="<?php echo $tglAkhir; ?>" />&nbsp;<input type="button" name="btnTgl" value="&nbsp;V&nbsp;" class="tblBtn" onClick="gfPop.fPopCalendar(document.getElementById('tglAkhir'),depRange);"/><button type="button" onClick="kirim()"><img src="../icon/lihat.gif" height="16" width="16" border="0" />&nbsp; Lihat</button></td>
                </tr>
                <tr>
                    <td height="30" style="padding-left:5px;"><select id="cmbPost" name="cmbPost" class="txtinput" style="background-color:#FFFFCC; color:#990000;" onChange="changePost(this.value);kirim()">
                        <option value="0">BELUM POSTING</option>
                        <option value="1">SUDAH POSTING</option>
                    </select></td>
                    <td height="30" align="right" style="padding-right:5px;">
                    <BUTTON type="button" disabled="disabled" id="btnKwitansi" onClick="CetakKwitansi();" style="cursor:pointer;"><IMG SRC="../icon/contact-us.jpg" border="0" width="16" height="16" ALIGN="absmiddle">&nbsp;Kwitansi JP</BUTTON>
                    <BUTTON id="btnPost" type="button" onClick="PostingJurnal()"><IMG SRC="../icon/save.gif" border="0" width="16" height="16" ALIGN="absmiddle">&nbsp;Posting >> Jurnal</BUTTON></td>
                </tr>
                <tr>
                    <td colspan="2" align="center">
                        <div id="gridbox" style="width:980px; height:300px; background-color:white; overflow:hidden;"></div>
                        <div id="paging" style="width:980px;"></div>
                    </td>
                </tr>
                <tr>
                    <td>&nbsp;</td>
                    <td>&nbsp;</td>
                </tr>
            </table>
        </div>
	</td>
</tr>
</table>
</div>
<script>
 	function kirim(){
	var url;
		url="../unit/pembelianObat_utils.php?grd=pembelianObat&tipe=<?php echo $tipe; ?>&tglAwal="+document.getElementById('tglAwal').value+"&tglAkhir="+document.getElementById('tglAkhir').value+"&posting="+document.getElementById('cmbPost').value;
		//alert(url);
		aGrid.loadURL(url,"","GET");
	} 
	
	function changePost(p){
		if (p==1){
			document.getElementById('btnPost').disabled=false;
			document.getElementById('btnPost').innerHTML="<IMG SRC='../icon/hapus.gif' border='0' width='16' height='16' ALIGN='absmiddle'>&nbsp;Unposting";
		}else{
			document.getElementById('btnPost').disabled=false;
			document.getElementById('btnPost').innerHTML="<IMG SRC='../icon/save.gif' border='0' width='16' height='16' ALIGN='absmiddle'>&nbsp;Posting >> Jurnal";
		}
	}
	
	function chkKlik(p){
	var cekbox=(p==true)?1:0;
		//alert(p);
		for (var i=0;i<aGrid.getMaxRow();i++){
			aGrid.cellsSetValue(i+1,10,cekbox);
		}
	}
	
	function CetakKwitansi()
	{
		//var no_bukti = document.getElementById('no_bukti').value;
		//var tgl = document.getElementById('tgl2').value;
		//alert(a1.getRowId(a1.getSelRow()));
		var url;
		var sisip = aGrid.getRowId(aGrid.getSelRow()).split("|");
		// alert(sisip);
		var idPosting = sisip[4];
		/*if(tgl=='')
		{
			alert('Pilih baris yang akan dicetak');
		}
		else
		{*/
			//url='../kwitansi/bukti.php?kw='+no_bukti+'&tipe=3&tgl='+sisip[2]+'&no_post='+idPosting+"&terima="+terima;
			url='../../keuangan/laporan/jurnal/bukti_jurnal_pembelian.php?id_posting='+idPosting;
			window.open(url);
			clear();
		//}
	}
	
	function PostingJurnal(){
	var tmp='',tmp2='';
	var url;
		//document.getElementById('btnPost').
		url="../unit/pembelianObat_utils.php?grd=pembelianObat&tipe=<?php echo $tipe; ?>&tglAwal="+document.getElementById('tglAwal').value+"&tglAkhir="+document.getElementById('tglAkhir').value+"&posting="+document.getElementById('cmbPost').value+"&idUser=<?php echo $iduser; ?>";
		
		for (var i=0;i<aGrid.getMaxRow();i++){
			if (aGrid.obj.childNodes[0].childNodes[i].childNodes[9].childNodes[0].checked){
				//alert(aGrid.cellsGetValue(i+1,3));
				tmp+=aGrid.getRowId(i+1)+String.fromCharCode(6);
				tmp2+=aGrid.getRowId(i+1)+"|";
			}
		}
		//alert(tmp);
		if (tmp!=""){
			tmp=tmp.substr(0,(tmp.length-1));
			//alert(tmp.length);
			url+="&act=postingBeliObat&fdata="+tmp;
			alert(url);
			//alert(tmp2);
			aGrid.loadURL(url,"","GET");
		}else{
			alert("Pilih Data Yg Mau diPosting Terlebih Dahulu !");
		}
	}
	
	function ValidasiText(p){
	var tmp=p;
		while (tmp.indexOf('.')>0){
			tmp=tmp.replace('.','');
		}
		while (tmp.indexOf(',')>0){
			tmp=tmp.replace(',','.');
		}
		return tmp;
	}

	function konfirmasi(key,val){
	var tmp;
		//alert(val+'-'+key);
		if (val!=undefined){
			tmp=val.split(String.fromCharCode(3));
			aGrid.cellSubTotalSetValue(7,tmp[1]);
			aGrid.cellSubTotalSetValue(8,tmp[2]);
			aGrid.cellSubTotalSetValue(9,tmp[3]);
			if(key=='Error'){
				if(tmp[0]=='postingBeliObat'){
					alert('Terjadi Error dlm Proses Posting !');
				}
			}else{
				if(tmp[0]=='postingBeliObat'){
					alert('Proses Posting Berhasil !');
				}
			}
			
			if (aGrid.getMaxPage()>0 && document.getElementById('cmbPost').value=="1"){
				document.getElementById('btnKwitansi').disabled=false;
			}else{
				document.getElementById('btnKwitansi').disabled=true;
			}
		}
	}
	
	function goFilterAndSort(grd){
	var url;
		//alert(grd);
		if (grd=="gridbox"){
			url="../unit/pembelianObat_utils.php?grd=pembelianObat&tipe=<?php echo $tipe; ?>&tglAwal="+document.getElementById('tglAwal').value+"&tglAkhir="+document.getElementById('tglAkhir').value+"&posting="+document.getElementById('cmbPost').value+"&filter="+aGrid.getFilter()+"&sorting="+aGrid.getSorting()+"&page="+aGrid.getPage();
			//alert(url);
			aGrid.loadURL(url,"","GET");
		}
	}
	
	var aGrid = new DSGridObject("gridbox");
	aGrid.setHeader("DATA TRANSAKSI PEMBELIAN OBAT");
	aGrid.setColHeader("NO,TANGGAL,NO GUDANG,NO FAKTUR,NO SPK,PBF,DPP,PPN,DPP + PPN,POSTING<BR><input type='checkbox' name='chkAll' id='chkAll' onClick='chkKlik(this.checked);'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;");
	aGrid.setSubTotal(",,,,,SubTotal :&nbsp;&nbsp;&nbsp;,0,0,0,");
	aGrid.setIDColHeader(",tgl1,noterima,no_faktur,no_spk,pbf_nama,,,,");
	aGrid.setColWidth("30,75,140,130,150,200,100,100,100,75");
	aGrid.setCellAlign("center,center,center,center,center,left,right,right,right,center");
	aGrid.setSubTotalAlign("center,center,center,center,center,right,right,right,right,center");
	aGrid.setCellType("txt,txt,txt,txt,txt,txt,txt,txt,txt,chk");
	aGrid.setCellHeight(20);
	aGrid.setImgPath("../icon");
	aGrid.setIDPaging("paging");
	aGrid.onLoaded(konfirmasi);
	//a.attachEvent("onRowClick");
	//alert("../unit/pembelianObat_utils.php?grd=pembelianObat&tglAwal="+document.getElementById('tglAwal').value+"&tglAkhir="+document.getElementById('tglAkhir').value);
	aGrid.baseURL("../unit/pembelianObat_utils.php?grd=pembelianObat&tipe=<?php echo $tipe; ?>&tglAwal="+document.getElementById('tglAwal').value+"&tglAkhir="+document.getElementById('tglAkhir').value);
	aGrid.Init();
</script>
</body>
</html>