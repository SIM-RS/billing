<?php
$dir = array(
	'js' => 'include/js',
	'css' => 'include/css',
	'img' => 'include/images'
);
?>