<html>
<head>
<title>Untitled Document</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link rel="stylesheet" href="theme/simkeu.css" type="text/css" />
</head>
<body>
<form>
<input type="button" value="Testing" class="butt" />
<input type="button" value="Testing" style="background-color: #6AB9BE;" />
<BUTTON>
  <IMG SRC="icon/link.gif" ALIGN="absmiddle">
  &nbsp;Close
</BUTTON>
</form>
</body>
</html>
