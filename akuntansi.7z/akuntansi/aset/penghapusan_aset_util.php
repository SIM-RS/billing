<?php 
session_start();
$user = $_SESSION['akun_iduser'];
include("../koneksi/konek.php");

/*$hostname_conn = "localhost";
$database_conn = "dbaset";
$username_conn = "root";
$password_conn = "";
$konek=mysql_connect($hostname_conn,$username_conn,$password_conn);
mysql_select_db($database_conn,$konek);*/
//====================================================================
//Paging,Sorting dan Filter======

$page=$_REQUEST["page"];
$sorting=$_REQUEST["sorting"];
$filter=$_REQUEST["filter"];
//====================================
$pilihan = $_REQUEST["pilihan"];
$tgl1 = explode("-",$_REQUEST["tgl1"]);
$tgl1 = $tgl1[2]."-".$tgl1[1]."-".$tgl1[0];
$tgl2 = explode("-",$_REQUEST["tgl2"]);
$tgl2 = $tgl2[2]."-".$tgl2[1]."-".$tgl2[0];
$defaultsort = "idseri";
$data = $_REQUEST["data"];
if ($filter!="") {
    $filter=explode("|",$filter);
    $filter=" AND ".$filter[0]." like '%".$filter[1]."%'";
}

if ($sorting=="") {
    $sorting=$defaultsort;
}
switch(strtolower($_REQUEST['act'])) {
	case 'posting':
	$data = explode("*", $data);
	$x = count($data)-1;
	for($v=0;$v<$x;$v++){
					$d = explode("|",$data[$v]);
					$d1 = mysql_query("select * from $dbakuntansi.ak_posting where tipe=13 and id_cc_rv = '".$d[1]."' and biayaRS_DPP_PPN = '".$d[2]."' and tgl_trans = '".$d[3]."'"); 
					$ro = mysql_num_rows($d1);
					if($ro==0){
						
					$sql1 = "insert into $dbakuntansi.ak_posting(id_cc_rv,tipe,biayaRS_DPP_PPN,tgl_trans,tgl_act,user_act)
					values('$d[1]','13','$d[2]','$d[3]',sysdate(),'$user')";
					$r = mysql_query($sql1);
					$pil = substr($d[4],0,2);
							switch($pil){
									case '01':
									$pil = 282;
									break;
									case '02':
									$pil = 288;
									break;
									case '03':
									$pil = 294;
									break;
									case '04':
									$pil = 300;
									break;
									case '05':
									$pil = 53;
									break;
									case '06':
									$pil = 35;
									break;
									case '07':
									$pil = 47;
									break;
									case '08':
									$pil = 41;									
									break;								
								}
								$no = mysql_query("select NO_TRANS from $dbakuntansi.jurnal order by NO_TRANS DESC limit 1");
								$data_no = mysql_fetch_array($no);
								$notrans = $data_no["NO_TRANS"]+1;
								$uraian = $d[4]."-".$d[5];
								$inj1 = "INSERT INTO $dbakuntansi.jurnal (NO_TRANS,FK_SAK,TGL,URAIAN,DEBIT,TGL_ACT,FK_IDUSER,
D_K,JENIS,FK_TRANS,FK_LAST_TRANS,NO_BUKTI,CC_RV_KSO_PBF_UMUM_ID) 
VALUES ('$notrans','$d[6]','$d[3]','$uraian','$d[2]',sysdate(),'$iduser','D','0','775','775','','$d[1]')";
								mysql_query($inj1);								
								$inj2 = "INSERT INTO $dbakuntansi.jurnal (NO_TRANS,FK_SAK,TGL,URAIAN,KREDIT,TGL_ACT,FK_IDUSER,
D_K,JENIS,FK_TRANS,FK_LAST_TRANS,NO_BUKTI,CC_RV_KSO_PBF_UMUM_ID) 
VALUES ('$notrans','774','$d[3]','$uraian','$d[2]',sysdate(),'$iduser','K','0','$pil','$pil','','$d[1]')";							
								mysql_query($inj2);	
					if(!$r){
								$dt="0".chr(5).chr(4).chr(5).$_REQUEST['act'];					
						}
						}else {
								$dt="0".chr(5).chr(4).chr(5).$_REQUEST['act'];
							}
		}
	//echo "hh";
	break;
	}
switch(strtolower($pilihan)) {
	case "hpsaset":
	if($q==1){
		$pos = "and k.posted = 1";
					
		}else if($q==0){
			$pos = "and k.posted = 0";
			}
			   $sql = "select * from $dbaset.as_seri2 s 
				inner join $dbaset.as_ms_barang b on s.idbarang=b.idbarang
				inner join $dbaset.as_ms_unit u on s.ms_idunit=u.idunit
				where tgl_hapus between '$tgl1' and '$tgl2'  
				 $filter order by $sorting";		
	break;	
	}
$rs=mysql_query($sql);
echo mysql_error();
$jmldata=mysql_num_rows($rs);
$perpage = 100;
if ($page=="" || $page=="0") $page=1;
$tpage=($page-1)*$perpage;
if (($jmldata%$perpage)>0) $totpage=floor($jmldata/$perpage)+1; else $totpage=floor($jmldata/$perpage);
if ($page>1) $bpage=$page-1; else $bpage=1;
if ($page<$totpage) $npage=$page+1; else $npage=$totpage;
$sql=$sql." limit $tpage,$perpage";
//echo $sql;

$rs=mysql_query($sql);
$i=($page-1)*$perpage;
$dt=$totpage.chr(5);

switch($pilihan) {
    case 'hpsaset':
    $i = 1;
    $cmb=$_REQUEST["cmb"];
    if($cmb == 0){
    while($rows = mysql_fetch_array($rs)){
    	if($rows['nilaibuku']=='')$rows['nilaibuku']=0;
    	$d = mysql_query("select * from $dbakuntansi.ak_posting where tipe=13 and id_cc_rv = '".$rows["idunit"]."' and biayaRS_DPP_PPN = '".$rows['nilaibuku']."' and tgl_trans = '".$rows["tgl_hapus"]."'"); 
		$ro = mysql_num_rows($d);
		if($ro==0){		
		$k = mysql_query("select ma_sak.ma_id from $dbakuntansi.ma_sak where ma_sak.ma_kode = '".$rows['kode_sak']."'");
		$dta = mysql_fetch_array($k);
							$dt .=$rows["idseri"]."|".$rows["idunit"]."|".$rows["nilaibuku"]."|".$rows["tgl_hapus"]."|".$rows["kodebarang"]."|".$rows["namabarang"]."|".$dta["ma_id"].chr(3).$i.chr(3).$rows['namaunit'].chr(3).$rows['kodebarang'].chr(3).$rows['namabarang'].chr(3).$rows['nilaibuku'].chr(3)."0".chr(6);
							$i++;
							}
							}
		}else if($cmb==1){
			
    while($rows = mysql_fetch_array($rs)){
    	if($rows['nilaibuku']=='')$rows['nilaibuku']=0;
    	$d = mysql_query("select * from $dbakuntansi.ak_posting where tipe=13 and id_cc_rv = '".$rows["idunit"]."' and biayaRS_DPP_PPN = '".$rows['nilaibuku']."' and tgl_trans = '".$rows["tgl_hapus"]."'"); 
		$ro = mysql_num_rows($d);
		if($ro>0){		
		$k = mysql_query("select ma_sak.ma_id from $dbakuntansi.ma_sak where ma_sak.ma_kode = '".$rows['kode_sak']."'");
		$dta = mysql_fetch_array($k);
							$dt .=$rows["idseri"]."|".$rows["idunit"]."|".$rows["nilaibuku"]."|".$rows["tgl_hapus"]."|".$rows["kodebarang"]."|".$rows["namabarang"]."|".$dta["ma_id"].chr(3).$i.chr(3).$rows['namaunit'].chr(3).$rows['kodebarang'].chr(3).$rows['namabarang'].chr(3).$rows['nilaibuku'].chr(3)."1".chr(6);
							$i++;
							}
							}
			}
		else if($cmb==2){
			
    while($rows = mysql_fetch_array($rs)){
    	if($rows['nilaibuku']=='')$rows['nilaibuku']=0;
    	$d = mysql_query("select * from $dbakuntansi.ak_posting where tipe=13 and id_cc_rv = '".$rows["idunit"]."' and biayaRS_DPP_PPN = '".$rows['nilaibuku']."' and tgl_trans = '".$rows["tgl_hapus"]."'"); 
		$ro = mysql_num_rows($d);
		$k = mysql_query("select ma_sak.ma_id from $dbakuntansi.ma_sak where ma_sak.ma_kode = '".$rows['kode_sak']."'");
		$dta = mysql_fetch_array($k);
							$dt .=$rows["idseri"]."|".$rows["idunit"]."|".$rows["nilaibuku"]."|".$rows["tgl_hapus"]."|".$rows["kodebarang"]."|".$rows["namabarang"]."|".$dta["ma_id"].chr(3).$i.chr(3).$rows['namaunit'].chr(3).$rows['kodebarang'].chr(3).$rows['namabarang'].chr(3).$rows['nilaibuku'].chr(3).$ro.chr(6);
							$i++;
							}
							
			}
			break;		
		}
		
//$dt="0".chr(5).chr(4).chr(5)."bb";

 if ($dt!=$totpage.chr(5)) {
        $dt=substr($dt,0,strlen($dt)-1).chr(5).$_REQUEST['act'];
        $dt=str_replace('"','\"',$dt);
    }
mysql_free_result($rs);
mysql_close($konek);

/*header("Cache-Control: no-cache, must-revalidate" );
header("Pragma: no-cache" );
if (stristr($_SERVER["HTTP_ACCEPT"],"application/xhtml+xml")) {
    header("Content-type: application/xhtml+xml");
}else {
    header("Content-type: text/xml");
}*/
echo $dt;

?>